"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";

export type MapMarker = {
  lat: number;
  lng: number;
  label?: string;
  tone?: "amber" | "emerald" | "sky" | "rose";
};

const TONE_CLASS: Record<string, string> = {
  amber: "bg-amber-500 ring-amber-200",
  emerald: "bg-emerald-500 ring-emerald-200",
  sky: "bg-sky-500 ring-sky-200",
  rose: "bg-rose-500 ring-rose-200",
};

function worldSize(zoom: number) {
  return 256 * Math.pow(2, zoom);
}

function lngToWorldX(lng: number, zoom: number) {
  return ((lng + 180) / 360) * worldSize(zoom);
}

function latToWorldY(lat: number, zoom: number) {
  const clamped = Math.max(Math.min(lat, 85.0511), -85.0511);
  const s = Math.sin((clamped * Math.PI) / 180);
  return (0.5 - Math.log((1 + s) / (1 - s)) / (4 * Math.PI)) * worldSize(zoom);
}

function worldXToLng(x: number, zoom: number) {
  return (x / worldSize(zoom)) * 360 - 180;
}

function worldYToLat(y: number, zoom: number) {
  const n = Math.PI - (2 * Math.PI * y) / worldSize(zoom);
  return (180 / Math.PI) * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n)));
}

const TILE_FALLBACK =
  "repeating-linear-gradient(45deg, #eceef2 0 10px, #f6f7f9 10px 20px)";

export default function TileMap({
  center,
  zoom: initialZoom = 13,
  markers = [],
  selectable = false,
  onSelect,
  className = "",
  height = 380,
}: {
  center?: { lat: number; lng: number };
  zoom?: number;
  markers?: MapMarker[];
  selectable?: boolean;
  onSelect?: (coords: { lat: number; lng: number }) => void;
  className?: string;
  height?: number;
}) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [size, setSize] = useState({ width: 640, height });
  const [zoom, setZoom] = useState(initialZoom);
  const [centerState, setCenterState] = useState(() => center ?? { lat: 6.4531, lng: 3.3958 });
  const dragRef = useRef<{ x: number; y: number; moved: boolean } | null>(null);
  const [dragging, setDragging] = useState(false);
  const [tileError, setTileError] = useState(false);

  useEffect(() => {
    if (center) setCenterState(center);
    if (typeof initialZoom === "number") setZoom(initialZoom);
  }, [center?.lat, center?.lng, initialZoom, center]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const observer = new ResizeObserver((entries) => {
      const rect = entries[0]?.contentRect;
      if (rect) setSize({ width: rect.width, height: rect.height });
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const centerPx = useMemo(
    () => ({
      x: lngToWorldX(centerState.lng, zoom),
      y: latToWorldY(centerState.lat, zoom),
    }),
    [centerState, zoom],
  );

  const topLeft = {
    x: centerPx.x - size.width / 2,
    y: centerPx.y - size.height / 2,
  };

  const tiles = useMemo(() => {
    const n = Math.pow(2, zoom);
    const minX = Math.floor(topLeft.x / 256);
    const maxX = Math.floor((topLeft.x + size.width) / 256);
    const minY = Math.floor(topLeft.y / 256);
    const maxY = Math.floor((topLeft.y + size.height) / 256);
    const out: { key: string; url: string; left: number; top: number }[] = [];
    for (let tx = minX; tx <= maxX; tx += 1) {
      for (let ty = minY; ty <= maxY; ty += 1) {
        if (ty < 0 || ty >= n) continue;
        const wrapped = ((tx % n) + n) % n;
        out.push({
          key: `${zoom}-${tx}-${ty}`,
          url: `https://tile.openstreetmap.org/${zoom}/${wrapped}/${ty}.png`,
          left: tx * 256 - topLeft.x,
          top: ty * 256 - topLeft.y,
        });
      }
    }
    return out;
  }, [topLeft.x, topLeft.y, size.width, size.height, zoom]);

  const onPointerDown = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      if (!selectable) return;
      dragRef.current = { x: e.clientX, y: e.clientY, moved: false };
      setDragging(true);
      (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    },
    [selectable],
  );

  const onPointerMove = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    const drag = dragRef.current;
    if (!drag) return;
    const dx = e.clientX - drag.x;
    const dy = e.clientY - drag.y;
    if (Math.abs(dx) + Math.abs(dy) > 3) drag.moved = true;
    drag.x = e.clientX;
    drag.y = e.clientY;
    setCenterState((prev) => {
      const x = lngToWorldX(prev.lng, zoom) - dx;
      const y = Math.max(
        0,
        Math.min(worldSize(zoom), latToWorldY(prev.lat, zoom) - dy),
      );
      return { lat: worldYToLat(y, zoom), lng: worldXToLng(x, zoom) };
    });
  }, [zoom]);

  const onPointerUp = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      const drag = dragRef.current;
      dragRef.current = null;
      setDragging(false);
      if (!selectable || !onSelect || drag?.moved) return;
      const rect = containerRef.current?.getBoundingClientRect();
      if (!rect) return;
      const x = topLeft.x + (e.clientX - rect.left);
      const y = topLeft.y + (e.clientY - rect.top);
      onSelect({
        lat: Number(worldYToLat(y, zoom).toFixed(6)),
        lng: Number(worldXToLng(x, zoom).toFixed(6)),
      });
    },
    [onSelect, selectable, topLeft.x, topLeft.y, zoom],
  );

  return (
    <div
      className={`relative overflow-hidden rounded-xl border border-asphalt-200 bg-asphalt-100 ${className}`}
      style={{ height, background: TILE_FALLBACK }}
    >
      <div
        ref={containerRef}
        className={`absolute inset-0 ${selectable ? "cursor-crosshair" : "cursor-grab"} ${
          dragging ? "cursor-grabbing" : ""
        }`}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        style={{ touchAction: "none" }}
      >
        {!tileError &&
          tiles.map((tile) => (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              key={tile.key}
              src={tile.url}
              alt=""
              width={256}
              height={256}
              loading="lazy"
              draggable={false}
              onError={() => setTileError(true)}
              className="pointer-events-none absolute select-none"
              style={{ left: tile.left, top: tile.top }}
            />
          ))}

        {markers.map((marker, index) => {
          const left = lngToWorldX(marker.lng, zoom) - topLeft.x;
          const top = latToWorldY(marker.lat, zoom) - topLeft.y;
          if (left < -40 || top < -40 || left > size.width + 40 || top > size.height + 40) return null;
          return (
            <div
              key={`${marker.lat}-${marker.lng}-${index}`}
              className="pointer-events-none absolute -translate-x-1/2 -translate-y-full"
              style={{ left, top }}
            >
              <div
                className={`marker-pin h-4 w-4 rounded-full ring-2 ${
                  TONE_CLASS[marker.tone ?? "amber"]
                }`}
              />
              {marker.label && (
                <span className="mt-1 inline-block max-w-[160px] -translate-x-1/3 truncate rounded-md bg-white/95 px-1.5 py-0.5 text-[10px] font-semibold text-asphalt-800 shadow">
                  {marker.label}
                </span>
              )}
            </div>
          );
        })}
      </div>

      <div className="absolute bottom-2 right-2 flex flex-col gap-1">
        <button
          type="button"
          onClick={() => setZoom((z) => Math.min(18, z + 1))}
          className="grid h-7 w-7 place-items-center rounded-md bg-white/95 text-sm font-bold text-asphalt-700 shadow"
          aria-label="Zoom in"
        >
          +
        </button>
        <button
          type="button"
          onClick={() => setZoom((z) => Math.max(2, z - 1))}
          className="grid h-7 w-7 place-items-center rounded-md bg-white/95 text-sm font-bold text-asphalt-700 shadow"
          aria-label="Zoom out"
        >
          −
        </button>
      </div>

      <div className="pointer-events-none absolute bottom-1 left-2 rounded bg-white/85 px-1.5 py-0.5 text-[10px] text-asphalt-500">
        {tileError ? "Map tiles unavailable · coordinates active" : "© OpenStreetMap contributors"}
      </div>
    </div>
  );
}
