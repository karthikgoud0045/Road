import Link from "next/link";
import { Logo } from "@/components/ui";

export default function SiteFooter() {
  return (
    <footer className="mt-16 border-t border-asphalt-200 bg-white">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-4">
        <div className="md:col-span-2">
          <Logo />
          <p className="mt-3 max-w-sm text-sm text-asphalt-500">
            RoadFix connects citizens, road authorities and maintenance crews on one platform so that
            potholes, cracks and damaged surfaces are reported, triaged and repaired in a transparent,
            trackable way.
          </p>
        </div>
        <div>
          <p className="text-xs font-bold uppercase tracking-wide text-asphalt-500">Citizens</p>
          <ul className="mt-3 space-y-2 text-sm text-asphalt-600">
            <li><Link className="hover:underline" href="/report">Report road damage</Link></li>
            <li><Link className="hover:underline" href="/reports">Browse live reports</Link></li>
            <li><Link className="hover:underline" href="/track">Track a report</Link></li>
          </ul>
        </div>
        <div>
          <p className="text-xs font-bold uppercase tracking-wide text-asphalt-500">Authorities</p>
          <ul className="mt-3 space-y-2 text-sm text-asphalt-600">
            <li><Link className="hover:underline" href="/dashboard">Complaint desk</Link></li>
            <li><Link className="hover:underline" href="/dashboard/work-orders">Work orders</Link></li>
            <li><Link className="hover:underline" href="/login">Staff sign in</Link></li>
          </ul>
        </div>
      </div>
      <div className="road-line" aria-hidden />
      <p className="pb-8 pt-4 text-center text-xs text-asphalt-400">
        Smart Road Damage Reporting & Maintenance Management System · demo build
      </p>
    </footer>
  );
}
