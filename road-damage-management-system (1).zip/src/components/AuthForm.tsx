"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

const DEMO = [
  {
    label: "Road authority officer",
    email: "authority@roadfix.gov",
    password: "demo1234",
    detail: "Triage complaints · create work orders",
  },
  {
    label: "Maintenance crew",
    email: "crew@roadfix.gov",
    password: "demo1234",
    detail: "View assigned jobs · log progress",
  },
  {
    label: "Citizen",
    email: "citizen@roadfix.gov",
    password: "demo1234",
    detail: "Report damage · follow repairs",
  },
];

export default function AuthForm({ mode }: { mode: "login" | "register" }) {
  const router = useRouter();
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    role: "citizen",
    phone: "",
    organisation: "",
  });
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  function update<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, mode }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Sign in failed");
        setBusy(false);
        return;
      }
      router.push(data.redirectTo ?? "/");
      router.refresh();
    } catch {
      setError("Network error. Please try again.");
      setBusy(false);
    }
  }

  function quickFill(email: string, password: string) {
    setForm((prev) => ({ ...prev, email, password }));
  }

  return (
    <div className="grid gap-6 md:grid-cols-[1fr_320px]">
      <form onSubmit={submit} className="card p-6">
        <h1 className="text-xl font-bold tracking-tight">
          {mode === "login" ? "Sign in to RoadFix" : "Create your account"}
        </h1>
        <p className="mt-1 text-sm text-asphalt-500">
          {mode === "login"
            ? "Citizens, road authority staff and maintenance crews all use the same sign-in."
            : "Citizens can register to track reports; staff accounts are created by the authority."}
        </p>

        <div className="mt-5 space-y-4">
          {mode === "register" && (
            <div>
              <label className="label" htmlFor="name">Full name</label>
              <input id="name" className="field" required value={form.name} onChange={(e) => update("name", e.target.value)} />
            </div>
          )}
          <div>
            <label className="label" htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              className="field"
              required
              autoComplete="email"
              value={form.email}
              onChange={(e) => update("email", e.target.value)}
            />
          </div>
          <div>
            <label className="label" htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              className="field"
              required
              autoComplete={mode === "login" ? "current-password" : "new-password"}
              value={form.password}
              onChange={(e) => update("password", e.target.value)}
            />
          </div>
          {mode === "register" && (
            <>
              <div>
                <label className="label" htmlFor="role">Account type</label>
                <select id="role" className="field" value={form.role} onChange={(e) => update("role", e.target.value)}>
                  <option value="citizen">Citizen</option>
                  <option value="crew">Maintenance crew</option>
                  <option value="authority">Road authority</option>
                </select>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="label" htmlFor="phone">Phone</label>
                  <input id="phone" className="field" value={form.phone} onChange={(e) => update("phone", e.target.value)} />
                </div>
                <div>
                  <label className="label" htmlFor="organisation">Organisation / crew</label>
                  <input
                    id="organisation"
                    className="field"
                    value={form.organisation}
                    onChange={(e) => update("organisation", e.target.value)}
                  />
                </div>
              </div>
            </>
          )}
        </div>

        {error && (
          <div className="mt-4 rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">{error}</div>
        )}

        <button type="submit" className="btn btn-accent mt-5 w-full py-2.5" disabled={busy}>
          {busy ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}
        </button>

        <p className="mt-4 text-sm text-asphalt-500">
          {mode === "login" ? (
            <>
              New citizen?{" "}
              <Link href="/register" className="font-semibold text-amber-700 hover:underline">
                Create an account
              </Link>
            </>
          ) : (
            <>
              Already registered?{" "}
              <Link href="/login" className="font-semibold text-amber-700 hover:underline">
                Sign in
              </Link>
            </>
          )}
        </p>
      </form>

      <aside className="card h-fit p-5">
        <h2 className="text-sm font-bold uppercase tracking-wide text-asphalt-500">Demo accounts</h2>
        <p className="mt-1 text-xs text-asphalt-500">
          Use a demo account to explore each role. Password is <span className="font-mono">demo1234</span>.
        </p>
        <ul className="mt-4 space-y-3">
          {DEMO.map((d) => (
            <li key={d.email} className="rounded-xl border border-asphalt-200 p-3">
              <p className="text-sm font-semibold text-asphalt-900">{d.label}</p>
              <p className="text-xs text-asphalt-500">{d.detail}</p>
              <p className="mt-1 font-mono text-[11px] text-asphalt-600">{d.email}</p>
              <button
                type="button"
                className="btn btn-ghost mt-2 w-full"
                onClick={() => quickFill(d.email, d.password)}
              >
                Fill credentials
              </button>
            </li>
          ))}
        </ul>
      </aside>
    </div>
  );
}
