"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { REPORT_STATUSES, REPORT_STATUS_LABEL, SEVERITIES, SEVERITY_LABEL } from "@/lib/constants";

export default function TriagePanel({
  reference,
  status,
  severity,
  compact = false,
}: {
  reference: string;
  status: string;
  severity: string;
  compact?: boolean;
}) {
  const router = useRouter();
  const [nextStatus, setNextStatus] = useState(status);
  const [nextSeverity, setNextSeverity] = useState(severity);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function apply(payload: { status?: string; severity?: string; message?: string; isPublic?: boolean }) {
    setBusy(true);
    setError(null);
    setMessage(null);
    const res = await fetch(`/api/reports/${reference}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) {
      setError(data.error ?? "Could not apply the decision");
      return;
    }
    setMessage("Decision recorded and added to the complaint timeline.");
    setNote("");
    router.refresh();
  }

  return (
    <div className="rounded-xl border border-asphalt-200 bg-asphalt-50/50 p-4">
      <p className="text-xs font-bold uppercase tracking-wide text-asphalt-500">
        Authority decision · {reference}
      </p>

      <div className="mt-3 flex flex-wrap gap-2">
        <button
          type="button"
          className="btn btn-primary text-xs"
          disabled={busy}
          onClick={() => apply({ status: "verified", message: note || undefined })}
        >
          ✅ Verify & accept
        </button>
        <button
          type="button"
          className="btn btn-ghost text-xs"
          disabled={busy}
          onClick={() => apply({ status: "rejected", message: note || "Not accepted for maintenance." })}
        >
          ⛔ Reject
        </button>
        <button
          type="button"
          className="btn btn-ghost text-xs"
          disabled={busy}
          onClick={() => apply({ status: "on_hold", message: note || "Placed on hold pending budget or materials." })}
        >
          ⏸ On hold
        </button>
        <button
          type="button"
          className="btn btn-ghost text-xs"
          disabled={busy}
          onClick={() => apply({ status: "closed", message: note || "Repair verified in the field and case closed." })}
        >
          🏁 Close case
        </button>
      </div>

      {!compact && (
        <>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor={`status-${reference}`}>Status</label>
              <select
                id={`status-${reference}`}
                className="field"
                value={nextStatus}
                onChange={(e) => setNextStatus(e.target.value)}
              >
                {REPORT_STATUSES.map((s) => (
                  <option key={s} value={s}>{REPORT_STATUS_LABEL[s]}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label" htmlFor={`severity-${reference}`}>Severity grading</label>
              <select
                id={`severity-${reference}`}
                className="field"
                value={nextSeverity}
                onChange={(e) => setNextSeverity(e.target.value)}
              >
                {SEVERITIES.map((s) => (
                  <option key={s} value={s}>{SEVERITY_LABEL[s]}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="mt-3">
            <label className="label" htmlFor={`note-${reference}`}>Review note</label>
            <textarea
              id={`note-${reference}`}
              className="field min-h-[70px]"
              placeholder="Field inspection findings, budget reference, planned works…"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              maxLength={800}
            />
          </div>

          <div className="mt-3 flex items-center gap-3">
            <button
              type="button"
              className="btn btn-accent text-xs"
              disabled={busy}
              onClick={() =>
                apply({
                  status: nextStatus !== status ? nextStatus : undefined,
                  severity: nextSeverity !== severity ? nextSeverity : undefined,
                  message: note || undefined,
                })
              }
            >
              {busy ? "Saving…" : "Save review"}
            </button>
            {message && <span className="text-xs text-emerald-600">{message}</span>}
            {error && <span className="text-xs text-rose-600">{error}</span>}
          </div>
        </>
      )}
      {compact && (message || error) && (
        <p className={`mt-2 text-xs ${error ? "text-rose-600" : "text-emerald-600"}`}>{error ?? message}</p>
      )}
    </div>
  );
}
