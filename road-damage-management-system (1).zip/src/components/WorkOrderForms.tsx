"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { WORK_SCOPES, WORK_SCOPE_LABEL, WORK_ORDER_STATUSES, WORK_ORDER_STATUS_LABEL } from "@/lib/constants";

type ReportOption = {
  reference: string;
  title: string;
  roadName: string;
  status: string;
};

type CrewOption = { id: number; name: string; zone: string | null };

export function WorkOrderComposer({
  reports,
  crews,
  defaultReference = "",
}: {
  reports: ReportOption[];
  crews: CrewOption[];
  defaultReference?: string;
}) {
  const router = useRouter();
  const eligible = reports.filter((r) => !["resolved", "closed", "rejected"].includes(r.status));
  const [form, setForm] = useState({
    reference: defaultReference || eligible[0]?.reference || "",
    title: "",
    scope: "patch_repair",
    crewId: crews[0]?.id ? String(crews[0].id) : "",
    scheduledStart: "",
    scheduledEnd: "",
    estimatedCost: "",
    materials: "",
    description: "",
    priority: "medium",
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [created, setCreated] = useState<string | null>(null);

  function update<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setCreated(null);
    const res = await fetch("/api/work-orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) {
      setError(data.error ?? "Could not create the work order");
      return;
    }
    setCreated(data.code);
    setForm((prev) => ({ ...prev, title: "", description: "", estimatedCost: "", materials: "" }));
    router.refresh();
  }

  return (
    <form onSubmit={submit} className="card p-5">
      <h2 className="text-lg font-bold">Dispatch a maintenance crew</h2>
      <p className="mt-1 text-sm text-asphalt-500">
        Turn a verified complaint into a scheduled work order with crew, scope and budget.
      </p>

      {eligible.length === 0 ? (
        <p className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800">
          There are no open complaints to dispatch. Verify a citizen report first.
        </p>
      ) : (
        <div className="mt-4 space-y-3">
          <div>
            <label className="label" htmlFor="wo-reference">Complaint</label>
            <select
              id="wo-reference"
              className="field"
              value={form.reference}
              onChange={(e) => update("reference", e.target.value)}
              required
            >
              {eligible.map((r) => (
                <option key={r.reference} value={r.reference}>
                  {r.reference} · {r.roadName} · {r.title}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="wo-title">Job title</label>
            <input
              id="wo-title"
              className="field"
              placeholder="Patch repair on the left lane"
              value={form.title}
              onChange={(e) => update("title", e.target.value)}
            />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="wo-scope">Scope of work</label>
              <select id="wo-scope" className="field" value={form.scope} onChange={(e) => update("scope", e.target.value)}>
                {WORK_SCOPES.map((s) => (
                  <option key={s} value={s}>{WORK_SCOPE_LABEL[s]}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label" htmlFor="wo-crew">Maintenance crew</label>
              <select id="wo-crew" className="field" value={form.crewId} onChange={(e) => update("crewId", e.target.value)}>
                <option value="">Unassigned</option>
                {crews.map((c) => (
                  <option key={c.id} value={String(c.id)}>
                    {c.name}
                    {c.zone ? ` · ${c.zone}` : ""}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label" htmlFor="wo-start">Scheduled start</label>
              <input
                id="wo-start"
                type="datetime-local"
                className="field"
                value={form.scheduledStart}
                onChange={(e) => update("scheduledStart", e.target.value)}
              />
            </div>
            <div>
              <label className="label" htmlFor="wo-end">Scheduled finish</label>
              <input
                id="wo-end"
                type="datetime-local"
                className="field"
                value={form.scheduledEnd}
                onChange={(e) => update("scheduledEnd", e.target.value)}
              />
            </div>
            <div>
              <label className="label" htmlFor="wo-cost">Estimated cost</label>
              <input
                id="wo-cost"
                type="number"
                min="0"
                step="1"
                className="field"
                placeholder="1500"
                value={form.estimatedCost}
                onChange={(e) => update("estimatedCost", e.target.value)}
              />
            </div>
            <div>
              <label className="label" htmlFor="wo-priority">Priority</label>
              <select id="wo-priority" className="field" value={form.priority} onChange={(e) => update("priority", e.target.value)}>
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="critical">Critical</option>
              </select>
            </div>
          </div>
          <div>
            <label className="label" htmlFor="wo-materials">Materials</label>
            <input
              id="wo-materials"
              className="field"
              placeholder="Cold mix asphalt 2t, road cones, warning signage"
              value={form.materials}
              onChange={(e) => update("materials", e.target.value)}
            />
          </div>
          <div>
            <label className="label" htmlFor="wo-description">Work instructions</label>
            <textarea
              id="wo-description"
              className="field min-h-[80px]"
              value={form.description}
              onChange={(e) => update("description", e.target.value)}
              maxLength={1000}
            />
          </div>

          {error && <p className="text-xs text-rose-600">{error}</p>}
          {created && (
            <p className="rounded-lg border border-emerald-200 bg-emerald-50 p-2 text-xs font-semibold text-emerald-700">
              Work order {created} created and the complaint moved to “Assigned”.
            </p>
          )}

          <button type="submit" className="btn btn-accent w-full" disabled={busy || !form.reference}>
            {busy ? "Creating…" : "Create work order & assign crew"}
          </button>
        </div>
      )}
    </form>
  );
}

export function WorkOrderProgressForm({
  id,
  status,
  progress,
  showCost = false,
}: {
  id: number;
  status: string;
  progress: number;
  showCost?: boolean;
}) {
  const router = useRouter();
  const [form, setForm] = useState({ status, progress: String(progress), message: "", actualCost: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const res = await fetch(`/api/work-orders/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        status: form.status !== status ? form.status : undefined,
        progress: Number(form.progress),
        message: form.message,
        actualCost: form.actualCost,
      }),
    });
    const data = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) {
      setError(data.error ?? "Could not save the update");
      return;
    }
    setForm((prev) => ({ ...prev, message: "" }));
    router.refresh();
  }

  return (
    <form onSubmit={submit} className="card p-5">
      <h2 className="text-lg font-bold">Log progress</h2>
      <p className="mt-1 text-sm text-asphalt-500">
        Post a field update. The linked complaint timeline is updated automatically.
      </p>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor={`wo-status-${id}`}>Status</label>
          <select
            id={`wo-status-${id}`}
            className="field"
            value={form.status}
            onChange={(e) => setForm((p) => ({ ...p, status: e.target.value }))}
          >
            {WORK_ORDER_STATUSES.map((s) => (
              <option key={s} value={s}>{WORK_ORDER_STATUS_LABEL[s]}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="label" htmlFor={`wo-progress-${id}`}>Progress · {form.progress}%</label>
          <input
            id={`wo-progress-${id}`}
            type="range"
            min={0}
            max={100}
            step={5}
            className="w-full accent-amber-500"
            value={form.progress}
            onChange={(e) => setForm((p) => ({ ...p, progress: e.target.value }))}
          />
        </div>
        {showCost && (
          <div>
            <label className="label" htmlFor={`wo-cost-${id}`}>Actual cost</label>
            <input
              id={`wo-cost-${id}`}
              type="number"
              min="0"
              step="1"
              className="field"
              value={form.actualCost}
              onChange={(e) => setForm((p) => ({ ...p, actualCost: e.target.value }))}
              placeholder="1750"
            />
          </div>
        )}
      </div>
      <div className="mt-3">
        <label className="label" htmlFor={`wo-note-${id}`}>Field note</label>
        <textarea
          id={`wo-note-${id}`}
          className="field min-h-[80px]"
          placeholder="Crew on site, lane closed, base layer filled…"
          value={form.message}
          onChange={(e) => setForm((p) => ({ ...p, message: e.target.value }))}
          maxLength={800}
        />
      </div>
      {error && <p className="mt-2 text-xs text-rose-600">{error}</p>}
      <button type="submit" className="btn btn-accent mt-3 w-full" disabled={busy}>
        {busy ? "Saving…" : "Save progress update"}
      </button>
    </form>
  );
}
