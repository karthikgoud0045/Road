"use client";

import Link from "next/link";
import { useState } from "react";
import TileMap from "@/components/TileMap";
import {
  DAMAGE_TYPES,
  DAMAGE_TYPE_ICON,
  DAMAGE_TYPE_LABEL,
  SEVERITIES,
  SEVERITY_LABEL,
} from "@/lib/constants";

const ZONES = ["Zone 1 · Central", "Zone 2 · North", "Zone 3 · South", "Zone 4 · East", "Zone 5 · West"];

type Success = { reference: string; title: string; duplicateOf?: string | null };

export default function ReportForm({
  defaultName = "",
  defaultEmail = "",
}: {
  defaultName?: string;
  defaultEmail?: string;
}) {
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [locating, setLocating] = useState(false);
  const [geoError, setGeoError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<Success | null>(null);
  const [form, setForm] = useState({
    title: "",
    description: "",
    damageType: "pothole",
    severity: "medium",
    roadName: "",
    landmark: "",
    zone: ZONES[0],
    photoUrl: "",
    reporterName: defaultName,
    reporterEmail: defaultEmail,
    reporterPhone: "",
  });

  function update<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function useMyLocation() {
    if (!navigator.geolocation) {
      setGeoError("Geolocation is not supported by this browser.");
      return;
    }
    setLocating(true);
    setGeoError(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCoords({
          lat: Number(pos.coords.latitude.toFixed(6)),
          lng: Number(pos.coords.longitude.toFixed(6)),
        });
        setLocating(false);
      },
      () => {
        setGeoError("Could not read your location. Tap the map to drop the pin manually.");
        setLocating(false);
      },
      { enableHighAccuracy: true, timeout: 8000 },
    );
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!coords) {
      setError("Please pin the damage location on the map.");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/reports", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, latitude: coords.lat, longitude: coords.lng }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Could not submit the report. Please try again.");
        return;
      }
      setSuccess(data.report as Success);
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  if (success) {
    return (
      <div className="card p-8 text-center">
        <span className="text-4xl">✅</span>
        <h2 className="mt-3 text-2xl font-bold">Report received</h2>
        <p className="mt-1 text-sm text-asphalt-500">
          Your complaint has been logged and queued for authority verification.
        </p>
        <div className="mx-auto mt-6 max-w-sm rounded-xl border border-dashed border-amber-400 bg-amber-50 p-5">
          <p className="text-xs font-bold uppercase tracking-wide text-amber-700">Reference code</p>
          <p className="mt-1 font-mono text-2xl font-extrabold tracking-tight text-asphalt-900">
            {success.reference}
          </p>
          <p className="mt-2 text-xs text-asphalt-500">
            Save this code — use it on the Track report page to follow progress.
          </p>
        </div>
        {success.duplicateOf && (
          <p className="mx-auto mt-4 max-w-md text-xs text-asphalt-500">
            Similar damage was already reported nearby (
            <Link href={`/reports/${success.duplicateOf}`} className="font-semibold text-amber-700 hover:underline">
              {success.duplicateOf}
            </Link>
            ). We still recorded your report and added a supporter to the existing case.
          </p>
        )}
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Link href={`/reports/${success.reference}`} className="btn btn-primary">
            Open report page
          </Link>
          <Link href="/track" className="btn btn-ghost">
            Track this report
          </Link>
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => {
              setSuccess(null);
              setCoords(null);
              setForm((prev) => ({
                ...prev,
                title: "",
                description: "",
                roadName: "",
                landmark: "",
                photoUrl: "",
              }));
            }}
          >
            File another report
          </button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="grid gap-6 lg:grid-cols-[1.25fr_1fr]">
      <div className="space-y-6">
        <div className="card p-6">
          <h2 className="text-lg font-bold">1 · Where is the damage?</h2>
          <p className="mt-1 text-sm text-asphalt-500">
            Tap the map to drop the pin at the exact spot, or use your device location.
          </p>
          <div className="mt-4">
            <TileMap
              selectable
              height={340}
              zoom={14}
              center={coords ?? undefined}
              markers={coords ? [{ ...coords, label: "Report location" }] : []}
              onSelect={(c) => setCoords(c)}
            />
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-3">
            <button type="button" onClick={useMyLocation} className="btn btn-ghost" disabled={locating}>
              {locating ? "Locating…" : "📍 Use my current location"}
            </button>
            <span className="font-mono text-xs text-asphalt-500">
              {coords ? `lat ${coords.lat.toFixed(5)}, lng ${coords.lng.toFixed(5)}` : "no pin selected"}
            </span>
          </div>
          {geoError && <p className="mt-2 text-xs text-rose-600">{geoError}</p>}

          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="roadName">Road / street name *</label>
              <input
                id="roadName"
                className="field"
                required
                placeholder="e.g. Independence Avenue"
                value={form.roadName}
                onChange={(e) => update("roadName", e.target.value)}
              />
            </div>
            <div>
              <label className="label" htmlFor="landmark">Nearest landmark</label>
              <input
                id="landmark"
                className="field"
                placeholder="e.g. opposite City Mall gate 2"
                value={form.landmark}
                onChange={(e) => update("landmark", e.target.value)}
              />
            </div>
            <div>
              <label className="label" htmlFor="zone">Administrative zone</label>
              <select id="zone" className="field" value={form.zone} onChange={(e) => update("zone", e.target.value)}>
                {ZONES.map((z) => (
                  <option key={z} value={z}>{z}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="card p-6">
          <h2 className="text-lg font-bold">2 · What is damaged?</h2>
          <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {DAMAGE_TYPES.map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => update("damageType", t)}
                className={`rounded-xl border p-3 text-left text-sm font-medium transition ${
                  form.damageType === t
                    ? "border-amber-400 bg-amber-50 text-asphalt-900"
                    : "border-asphalt-200 bg-white text-asphalt-600 hover:border-asphalt-300"
                }`}
              >
                <span className="text-lg">{DAMAGE_TYPE_ICON[t]}</span>
                <span className="mt-1 block">{DAMAGE_TYPE_LABEL[t]}</span>
              </button>
            ))}
          </div>

          <div className="mt-5">
            <label className="label" htmlFor="title">Short title *</label>
            <input
              id="title"
              className="field"
              required
              maxLength={120}
              placeholder="e.g. Deep pothole in the left lane"
              value={form.title}
              onChange={(e) => update("title", e.target.value)}
            />
          </div>

          <div className="mt-4">
            <label className="label" htmlFor="description">Describe the damage *</label>
            <textarea
              id="description"
              className="field min-h-[110px]"
              required
              maxLength={1200}
              placeholder="Size, depth, when you noticed it, whether it affects traffic or pedestrians…"
              value={form.description}
              onChange={(e) => update("description", e.target.value)}
            />
          </div>

          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="severity">How serious is it?</label>
              <select id="severity" className="field" value={form.severity} onChange={(e) => update("severity", e.target.value)}>
                {SEVERITIES.map((s) => (
                  <option key={s} value={s}>{SEVERITY_LABEL[s]}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label" htmlFor="photoUrl">Photo link (optional)</label>
              <input
                id="photoUrl"
                className="field"
                placeholder="https://…/pothole.jpg"
                value={form.photoUrl}
                onChange={(e) => update("photoUrl", e.target.value)}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="card p-6">
          <h2 className="text-lg font-bold">3 · Your contact details</h2>
          <p className="mt-1 text-sm text-asphalt-500">
            Used only by the road authority to follow up on this complaint.
          </p>
          <div className="mt-4 space-y-4">
            <div>
              <label className="label" htmlFor="reporterName">Full name *</label>
              <input
                id="reporterName"
                className="field"
                required
                value={form.reporterName}
                onChange={(e) => update("reporterName", e.target.value)}
              />
            </div>
            <div>
              <label className="label" htmlFor="reporterEmail">Email</label>
              <input
                id="reporterEmail"
                type="email"
                className="field"
                value={form.reporterEmail}
                onChange={(e) => update("reporterEmail", e.target.value)}
              />
            </div>
            <div>
              <label className="label" htmlFor="reporterPhone">Phone</label>
              <input
                id="reporterPhone"
                className="field"
                value={form.reporterPhone}
                onChange={(e) => update("reporterPhone", e.target.value)}
              />
            </div>
          </div>
        </div>

        {error && (
          <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">{error}</div>
        )}

        <button type="submit" className="btn btn-accent w-full py-3" disabled={submitting}>
          {submitting ? "Submitting…" : "Submit road damage report"}
        </button>
        <p className="text-xs leading-relaxed text-asphalt-500">
          By submitting you confirm the information is accurate. False or malicious reports may be
          rejected by the road authority and are recorded against your account.
        </p>
      </div>
    </form>
  );
}
