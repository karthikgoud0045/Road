import Link from "next/link";
import { logoutAction } from "@/app/actions";
import { getCurrentUser, roleHomePath } from "@/lib/auth";
import { ROLE_LABEL, type Role } from "@/lib/constants";
import { Logo } from "@/components/ui";
import { initials } from "@/lib/format";

const PUBLIC_NAV = [
  { href: "/", label: "Home" },
  { href: "/report", label: "Report damage" },
  { href: "/reports", label: "Live reports" },
  { href: "/track", label: "Track report" },
];

export default async function SiteHeader() {
  const user = await getCurrentUser();
  const role = user?.role as Role | undefined;

  const nav = [...PUBLIC_NAV];
  if (role === "authority") nav.splice(2, 0, { href: "/dashboard", label: "Authority desk" });
  if (role === "crew") nav.splice(2, 0, { href: "/crew", label: "Crew jobs" });
  if (role === "citizen") nav.splice(2, 0, { href: "/my-reports", label: "My reports" });

  return (
    <header className="sticky top-0 z-40 border-b border-asphalt-200 bg-white/85 backdrop-blur">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3 sm:px-6">
        <Link href="/" className="shrink-0">
          <Logo />
        </Link>

        <nav className="order-3 flex w-full flex-wrap items-center gap-1 sm:order-2 sm:w-auto sm:flex-1">
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-lg px-3 py-1.5 text-sm font-medium text-asphalt-600 transition hover:bg-asphalt-100 hover:text-asphalt-900"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="order-2 ml-auto flex items-center gap-2 sm:order-3">
          {user ? (
            <>
              <Link
                href={roleHomePath(user.role)}
                className="flex items-center gap-2 rounded-xl border border-asphalt-200 bg-white px-2.5 py-1.5"
              >
                <span className="grid h-7 w-7 place-items-center rounded-lg bg-asphalt-900 text-[11px] font-bold text-amber-400">
                  {initials(user.name)}
                </span>
                <span className="hidden leading-tight sm:block">
                  <span className="block max-w-[140px] truncate text-xs font-semibold text-asphalt-900">
                    {user.name}
                  </span>
                  <span className="block text-[10px] uppercase tracking-wide text-asphalt-500">
                    {ROLE_LABEL[role ?? "citizen"]}
                  </span>
                </span>
              </Link>
              <form action={logoutAction}>
                <button type="submit" className="btn btn-ghost">
                  Sign out
                </button>
              </form>
            </>
          ) : (
            <>
              <Link href="/login" className="btn btn-ghost">
                Sign in
              </Link>
              <Link href="/report" className="btn btn-accent">
                Report an issue
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
