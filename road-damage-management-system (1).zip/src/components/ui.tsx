import Link from "next/link";
import type { ReactNode } from "react";
import {
  DAMAGE_TYPE_ICON,
  DAMAGE_TYPE_LABEL,
  REPORT_STATUS_LABEL,
  REPORT_STATUS_TONE,
  SEVERITY_LABEL,
  WORK_ORDER_STATUS_LABEL,
  WORK_ORDER_STATUS_TONE,
  type DamageType,
  type ReportStatus,
  type Severity,
  type WorkOrderStatus,
} from "@/lib/constants";

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <span className="flex items-center gap-2">
      <span className="relative grid h-9 w-9 place-items-center rounded-xl bg-asphalt-900 text-amber-400">
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={1.8}>
          <path d="M8 3 5 21" strokeLinecap="round" />
          <path d="M16 3 19 21" strokeLinecap="round" />
          <path d="M12 6v2M12 12v2M12 18v2" strokeLinecap="round" />
        </svg>
      </span>
      {!compact && (
        <span className="leading-tight">
          <span className="block text-sm font-extrabold tracking-tight text-asphalt-900">RoadFix</span>
          <span className="block text-[10px] font-medium uppercase tracking-[0.14em] text-asphalt-500">
            Damage & Maintenance
          </span>
        </span>
      )}
    </span>
  );
}

export function Chip({
  children,
  tone = "bg-asphalt-50 text-asphalt-700 ring-asphalt-200",
  className = "",
}: {
  children: ReactNode;
  tone?: string;
  className?: string;
}) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset ${tone} ${className}`}
    >
      {children}
    </span>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const key = status as ReportStatus;
  return (
    <Chip tone={REPORT_STATUS_TONE[key] ?? "bg-asphalt-50 text-asphalt-700 ring-asphalt-200"}>
      {REPORT_STATUS_LABEL[key] ?? status}
    </Chip>
  );
}

export function WorkOrderBadge({ status }: { status: string }) {
  const key = status as WorkOrderStatus;
  return (
    <Chip tone={WORK_ORDER_STATUS_TONE[key] ?? "bg-asphalt-50 text-asphalt-700 ring-asphalt-200"}>
      {WORK_ORDER_STATUS_LABEL[key] ?? status}
    </Chip>
  );
}

const SEVERITY_TONE: Record<Severity, string> = {
  low: "bg-teal-50 text-teal-700 ring-teal-200",
  medium: "bg-amber-50 text-amber-700 ring-amber-200",
  high: "bg-orange-50 text-orange-700 ring-orange-300",
  critical: "bg-red-50 text-red-700 ring-red-300",
};

export function SeverityBadge({ severity }: { severity: string }) {
  const key = (severity as Severity) ?? "medium";
  return (
    <Chip tone={SEVERITY_TONE[key] ?? SEVERITY_TONE.medium}>
      {SEVERITY_LABEL[key] ?? severity}
    </Chip>
  );
}

export function DamageChip({ type }: { type: string }) {
  const key = (type as DamageType) ?? "other";
  return (
    <Chip tone="bg-asphalt-50 text-asphalt-700 ring-asphalt-200">
      <span aria-hidden>{DAMAGE_TYPE_ICON[key] ?? "📍"}</span>
      {DAMAGE_TYPE_LABEL[key] ?? type}
    </Chip>
  );
}

export function StatCard({
  label,
  value,
  hint,
  tone = "text-asphalt-900",
  icon,
}: {
  label: string;
  value: ReactNode;
  hint?: string;
  tone?: string;
  icon?: ReactNode;
}) {
  return (
    <div className="card p-4">
      <div className="flex items-start justify-between gap-3">
        <p className="text-xs font-semibold uppercase tracking-wide text-asphalt-500">{label}</p>
        {icon && <span className="text-lg leading-none">{icon}</span>}
      </div>
      <p className={`mt-2 text-2xl font-extrabold tracking-tight ${tone}`}>{value}</p>
      {hint && <p className="mt-1 text-xs text-asphalt-500">{hint}</p>}
    </div>
  );
}

export function ProgressBar({ value, tone = "bg-asphalt-900" }: { value: number; tone?: string }) {
  const pct = Math.max(0, Math.min(100, value));
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-asphalt-100">
      <div className={`h-full rounded-full ${tone}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

export function BarList({
  items,
  emptyLabel = "No data yet",
}: {
  items: { label: string; value: number; sub?: string; tone?: string }[];
  emptyLabel?: string;
}) {
  if (items.length === 0) return <p className="text-sm text-asphalt-500">{emptyLabel}</p>;
  const max = Math.max(...items.map((i) => i.value), 1);
  return (
    <ul className="space-y-3">
      {items.map((item) => (
        <li key={item.label}>
          <div className="flex items-baseline justify-between gap-3 text-sm">
            <span className="font-medium text-asphalt-800">{item.label}</span>
            <span className="tabular-nums text-asphalt-500">
              {item.value}
              {item.sub ? ` · ${item.sub}` : ""}
            </span>
          </div>
          <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-asphalt-100">
            <div
              className={`h-full rounded-full ${item.tone ?? "bg-asphalt-700"}`}
              style={{ width: `${Math.max(6, (item.value / max) * 100)}%` }}
            />
          </div>
        </li>
      ))}
    </ul>
  );
}

export function EmptyState({
  title,
  description,
  action,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="card flex flex-col items-center gap-2 p-10 text-center">
      <span className="text-3xl">🛣️</span>
      <p className="font-semibold text-asphalt-800">{title}</p>
      {description && <p className="max-w-md text-sm text-asphalt-500">{description}</p>}
      {action}
    </div>
  );
}

export function ReferenceLink({ reference }: { reference: string }) {
  return (
    <Link
      href={`/reports/${reference}`}
      className="font-mono text-xs font-semibold text-amber-700 hover:underline"
    >
      {reference}
    </Link>
  );
}

export function SectionHeading({
  title,
  description,
  action,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-3">
      <div>
        <h2 className="text-lg font-bold tracking-tight text-asphalt-900">{title}</h2>
        {description && <p className="mt-0.5 text-sm text-asphalt-500">{description}</p>}
      </div>
      {action}
    </div>
  );
}
