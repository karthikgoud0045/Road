"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";

export function SupportButton({
  reference,
  initial,
  disabled,
}: {
  reference: string;
  initial: number;
  disabled?: boolean;
}) {
  const [count, setCount] = useState(initial);
  const [done, setDone] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  async function support() {
    if (done || disabled) return;
    const res = await fetch("/api/reports", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reference }),
    });
    if (res.ok) {
      const data = await res.json();
      setCount(Number(data.supports ?? count + 1));
      setDone(true);
      startTransition(() => router.refresh());
    }
  }

  return (
    <button
      type="button"
      onClick={support}
      disabled={done || pending || disabled}
      className={`btn ${done ? "btn-primary" : "btn-ghost"}`}
      title={disabled ? "Sign in to support a report" : "Support this report"}
    >
      👍 {done ? "Supported" : "Support"} · {count}
    </button>
  );
}

export function CommentForm({ reference }: { reference: string }) {
  const router = useRouter();
  const [message, setMessage] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const res = await fetch(`/api/reports/${reference}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });
    const data = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) {
      setError(data.error ?? "Could not post your comment");
      return;
    }
    setMessage("");
    router.refresh();
  }

  return (
    <form onSubmit={submit} className="space-y-3">
      <textarea
        className="field min-h-[90px]"
        placeholder="Add an update, a photo link or ask the authority for information…"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        maxLength={1000}
      />
      {error && <p className="text-xs text-rose-600">{error}</p>}
      <div className="flex justify-end">
        <button type="submit" className="btn btn-primary" disabled={busy || message.trim().length < 2}>
          {busy ? "Posting…" : "Post update"}
        </button>
      </div>
    </form>
  );
}
