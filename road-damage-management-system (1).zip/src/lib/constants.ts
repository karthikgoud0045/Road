export const ROLES = ["citizen", "authority", "crew"] as const;
export type Role = (typeof ROLES)[number];

export const ROLE_LABEL: Record<Role, string> = {
  citizen: "Citizen",
  authority: "Road Authority",
  crew: "Maintenance Crew",
};

export const DAMAGE_TYPES = [
  "pothole",
  "crack",
  "surface_wear",
  "edge_break",
  "flooding",
  "debris",
  "sign_damage",
  "other",
] as const;
export type DamageType = (typeof DAMAGE_TYPES)[number];

export const DAMAGE_TYPE_LABEL: Record<DamageType, string> = {
  pothole: "Pothole",
  crack: "Crack",
  surface_wear: "Surface wear",
  edge_break: "Edge break",
  flooding: "Water logging",
  debris: "Debris / obstruction",
  sign_damage: "Damaged sign / marking",
  other: "Other",
};

export const DAMAGE_TYPE_ICON: Record<DamageType, string> = {
  pothole: "🕳️",
  crack: "〰️",
  surface_wear: "🛣️",
  edge_break: "🧱",
  flooding: "💧",
  debris: "🪨",
  sign_damage: "🚧",
  other: "📍",
};

export const SEVERITIES = ["low", "medium", "high", "critical"] as const;
export type Severity = (typeof SEVERITIES)[number];

export const SEVERITY_LABEL: Record<Severity, string> = {
  low: "Low",
  medium: "Medium",
  high: "High",
  critical: "Critical",
};

/** Target resolution window in days, used for SLA ageing. */
export const SEVERITY_SLA_DAYS: Record<Severity, number> = {
  low: 21,
  medium: 14,
  high: 7,
  critical: 2,
};

export const SEVERITY_WEIGHT: Record<Severity, number> = {
  low: 1,
  medium: 2,
  high: 3,
  critical: 4,
};

export const REPORT_STATUSES = [
  "submitted",
  "verified",
  "rejected",
  "assigned",
  "in_progress",
  "on_hold",
  "resolved",
  "closed",
] as const;
export type ReportStatus = (typeof REPORT_STATUSES)[number];

export const REPORT_STATUS_LABEL: Record<ReportStatus, string> = {
  submitted: "Submitted",
  verified: "Verified",
  rejected: "Rejected",
  assigned: "Assigned",
  in_progress: "Repair in progress",
  on_hold: "On hold",
  resolved: "Resolved",
  closed: "Closed",
};

export const REPORT_STATUS_TONE: Record<ReportStatus, string> = {
  submitted: "bg-sky-50 text-sky-700 ring-sky-200",
  verified: "bg-indigo-50 text-indigo-700 ring-indigo-200",
  rejected: "bg-slate-100 text-slate-600 ring-slate-300",
  assigned: "bg-amber-50 text-amber-700 ring-amber-200",
  in_progress: "bg-orange-50 text-orange-700 ring-orange-200",
  on_hold: "bg-rose-50 text-rose-700 ring-rose-200",
  resolved: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  closed: "bg-emerald-100 text-emerald-800 ring-emerald-300",
};

export const WORK_ORDER_STATUSES = [
  "scheduled",
  "in_progress",
  "paused",
  "completed",
  "cancelled",
] as const;
export type WorkOrderStatus = (typeof WORK_ORDER_STATUSES)[number];

export const WORK_ORDER_STATUS_LABEL: Record<WorkOrderStatus, string> = {
  scheduled: "Scheduled",
  in_progress: "In progress",
  paused: "Paused",
  completed: "Completed",
  cancelled: "Cancelled",
};

export const WORK_ORDER_STATUS_TONE: Record<WorkOrderStatus, string> = {
  scheduled: "bg-amber-50 text-amber-700 ring-amber-200",
  in_progress: "bg-sky-50 text-sky-700 ring-sky-200",
  paused: "bg-rose-50 text-rose-700 ring-rose-200",
  completed: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  cancelled: "bg-slate-100 text-slate-600 ring-slate-300",
};

export const WORK_SCOPES = [
  "patch_repair",
  "resurfacing",
  "crack_sealing",
  "drainage",
  "clearing",
  "signage",
  "full_reconstruction",
] as const;
export type WorkScope = (typeof WORK_SCOPES)[number];

export const WORK_SCOPE_LABEL: Record<WorkScope, string> = {
  patch_repair: "Patch repair",
  resurfacing: "Resurfacing",
  crack_sealing: "Crack sealing",
  drainage: "Drainage work",
  clearing: "Clearing / removal",
  signage: "Signage & marking",
  full_reconstruction: "Full reconstruction",
};

/** Statuses that mean the report is no longer waiting on someone. */
export const CLOSED_REPORT_STATUSES: ReportStatus[] = ["resolved", "closed", "rejected"];

export function isReportStatus(value: string): value is ReportStatus {
  return (REPORT_STATUSES as readonly string[]).includes(value);
}

export function isDamageType(value: string): value is DamageType {
  return (DAMAGE_TYPES as readonly string[]).includes(value);
}

export function isSeverity(value: string): value is Severity {
  return (SEVERITIES as readonly string[]).includes(value);
}

export function isWorkOrderStatus(value: string): value is WorkOrderStatus {
  return (WORK_ORDER_STATUSES as readonly string[]).includes(value);
}

export function isRole(value: string): value is Role {
  return (ROLES as readonly string[]).includes(value);
}
