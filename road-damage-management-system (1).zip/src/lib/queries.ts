import { and, count, desc, eq, gte, ilike, inArray, or, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { reports, reportUpdates, users, workOrders, workOrderUpdates } from "@/db/schema";
import { SEVERITY_WEIGHT, type DamageType, type Severity } from "@/lib/constants";

export type ReportRow = typeof reports.$inferSelect & { crewName: string | null };

export async function nextReference(prefix: string, table: "reports" | "work_orders") {
  const year = new Date().getFullYear();
  const rows =
    table === "reports"
      ? await db
          .select({ n: count() })
          .from(reports)
          .where(sql`${reports.reference} like ${prefix + year + "-%"}`)
      : await db
          .select({ n: count() })
          .from(workOrders)
          .where(sql`${workOrders.code} like ${prefix + year + "-%"}`);
  const existing = Number(rows[0]?.n ?? 0);
  let seq = existing + 1;
  // Guard against collisions after deletions.
  for (let i = 0; i < 50; i += 1) {
    const candidate = `${prefix}${year}-${String(seq).padStart(4, "0")}`;
    const taken =
      table === "reports"
        ? await db.select({ id: reports.id }).from(reports).where(eq(reports.reference, candidate)).limit(1)
        : await db.select({ id: workOrders.id }).from(workOrders).where(eq(workOrders.code, candidate)).limit(1);
    if (taken.length === 0) return candidate;
    seq += 1;
  }
  return `${prefix}${year}-${Date.now().toString().slice(-5)}`;
}

export function priorityScore(severity: string, createdAt: Date | string, supports: number): number {
  const weight = SEVERITY_WEIGHT[(severity as Severity) ?? "medium"] ?? 2;
  const ageDays = Math.max(
    0,
    Math.floor((Date.now() - new Date(createdAt).getTime()) / 86400000),
  );
  return Math.round(weight * 20 + Math.min(ageDays, 30) * 1.5 + Math.min(supports, 50) * 0.5);
}

export type ReportFilters = {
  q?: string;
  status?: string;
  damageType?: string;
  severity?: string;
  zone?: string;
  crewId?: number;
  reporterId?: number;
  limit?: number;
};

export async function listReports(filters: ReportFilters = {}): Promise<ReportRow[]> {
  const conditions: SQL[] = [];
  if (filters.q) {
    const like = `%${filters.q}%`;
    const search = or(
      ilike(reports.title, like),
      ilike(reports.roadName, like),
      ilike(reports.reference, like),
      ilike(reports.landmark, like),
      ilike(reports.reporterName, like),
    );
    if (search) conditions.push(search);
  }
  if (filters.status) {
    const statuses = filters.status.split(",").filter(Boolean);
    if (statuses.length > 0) conditions.push(inArray(reports.status, statuses));
  }
  if (filters.damageType) conditions.push(eq(reports.damageType, filters.damageType));
  if (filters.severity) conditions.push(eq(reports.severity, filters.severity));
  if (filters.zone) conditions.push(eq(reports.zone, filters.zone));
  if (filters.crewId) conditions.push(eq(reports.assignedCrewId, filters.crewId));
  if (filters.reporterId) conditions.push(eq(reports.reporterId, filters.reporterId));

  const rows = await db
    .select({
      report: reports,
      crewName: users.name,
    })
    .from(reports)
    .leftJoin(users, eq(users.id, reports.assignedCrewId))
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(reports.createdAt))
    .limit(filters.limit ?? 200);

  return rows.map((row) => ({ ...row.report, crewName: row.crewName ?? null }));
}

export async function getReportByReference(reference: string) {
  const rows = await db
    .select({ report: reports, crewName: users.name })
    .from(reports)
    .leftJoin(users, eq(users.id, reports.assignedCrewId))
    .where(eq(reports.reference, reference))
    .limit(1);
  const found = rows[0];
  if (!found) return null;
  const timeline = await db
    .select()
    .from(reportUpdates)
    .where(eq(reportUpdates.reportId, found.report.id))
    .orderBy(desc(reportUpdates.createdAt));
  const orders = await db
    .select({ order: workOrders, crewName: users.name })
    .from(workOrders)
    .leftJoin(users, eq(users.id, workOrders.crewId))
    .where(eq(workOrders.reportId, found.report.id))
    .orderBy(desc(workOrders.createdAt));
  return {
    report: { ...found.report, crewName: found.crewName ?? null } as ReportRow,
    timeline,
    workOrders: orders.map((o) => ({ ...o.order, crewName: o.crewName ?? null })),
  };
}

export type DashboardStats = {
  total: number;
  open: number;
  resolved: number;
  rejected: number;
  inProgress: number;
  critical: number;
  overdue: number;
  last7Days: number;
  avgResolutionDays: number | null;
  byStatus: { status: string; total: number }[];
  byType: { damageType: DamageType; total: number }[];
  bySeverity: { severity: Severity; total: number }[];
  byZone: { zone: string; total: number; open: number }[];
};

export async function dashboardStats(): Promise<DashboardStats> {
  const all = await db.select().from(reports).orderBy(desc(reports.createdAt)).limit(2000);
  const resolvedAges: number[] = [];
  let resolved = 0;
  let rejected = 0;
  let critical = 0;
  let overdue = 0;
  let last7 = 0;
  const weekAgo = Date.now() - 7 * 86400000;

  const statusMap = new Map<string, number>();
  const typeMap = new Map<string, number>();
  const severityMap = new Map<string, number>();
  const zoneMap = new Map<string, { total: number; open: number }>();

  for (const r of all) {
    statusMap.set(r.status, (statusMap.get(r.status) ?? 0) + 1);
    typeMap.set(r.damageType, (typeMap.get(r.damageType) ?? 0) + 1);
    severityMap.set(r.severity, (severityMap.get(r.severity) ?? 0) + 1);
    const zone = r.zone ?? "Unzoned";
    const z = zoneMap.get(zone) ?? { total: 0, open: 0 };
    z.total += 1;
    if (!["resolved", "closed", "rejected"].includes(r.status)) z.open += 1;
    zoneMap.set(zone, z);

    if (r.status === "resolved" || r.status === "closed") {
      resolved += 1;
      if (r.resolvedAt) {
        resolvedAges.push(
          Math.max(0, (new Date(r.resolvedAt).getTime() - new Date(r.createdAt).getTime()) / 86400000),
        );
      }
    }
    if (r.status === "rejected") rejected += 1;
    if (r.severity === "critical" && !["resolved", "closed", "rejected"].includes(r.status)) critical += 1;
    if (new Date(r.createdAt).getTime() > weekAgo) last7 += 1;
  }

  const open = all.filter((r) => !["resolved", "closed", "rejected"].includes(r.status)).length;

  return {
    total: all.length,
    open,
    resolved,
    rejected,
    critical,
    inProgress: statusMap.get("in_progress") ?? 0,
    last7Days: last7,
    overdue: overdue,
    avgResolutionDays:
      resolvedAges.length > 0
        ? Math.round((resolvedAges.reduce((a, b) => a + b, 0) / resolvedAges.length) * 10) / 10
        : null,
    byStatus: [...statusMap.entries()].map(([status, total]) => ({ status, total })),
    byType: [...typeMap.entries()]
      .map(([damageType, total]) => ({ damageType: damageType as DamageType, total }))
      .sort((a, b) => b.total - a.total),
    bySeverity: [...severityMap.entries()]
      .map(([severity, total]) => ({ severity: severity as Severity, total }))
      .sort((a, b) => SEVERITY_WEIGHT[b.severity] - SEVERITY_WEIGHT[a.severity]),
    byZone: [...zoneMap.entries()]
      .map(([zone, v]) => ({ zone, ...v }))
      .sort((a, b) => b.total - a.total),
  };
}

export async function overdueReports(limit = 8) {
  const rows = await db
    .select()
    .from(reports)
    .where(
      and(
        inArray(reports.severity, ["critical", "high"]),
        inArray(reports.status, ["submitted", "verified", "assigned", "in_progress", "on_hold"]),
        sql`${reports.createdAt} < now() - interval '5 days'`,
      ),
    )
    .orderBy(reports.createdAt)
    .limit(limit);
  return rows;
}

export async function recentActivity(limit = 10) {
  const rows = await db
    .select({
      id: reportUpdates.id,
      reportId: reportUpdates.reportId,
      reference: reports.reference,
      title: reports.title,
      authorName: reportUpdates.authorName,
      authorRole: reportUpdates.authorRole,
      message: reportUpdates.message,
      statusTo: reportUpdates.statusTo,
      createdAt: reportUpdates.createdAt,
    })
    .from(reportUpdates)
    .innerJoin(reports, eq(reports.id, reportUpdates.reportId))
    .orderBy(desc(reportUpdates.createdAt))
    .limit(limit);
  return rows;
}

export async function listWorkOrders(filters: { status?: string; crewId?: number; limit?: number } = {}) {
  const conditions: SQL[] = [];
  if (filters.status) conditions.push(eq(workOrders.status, filters.status));
  if (filters.crewId) conditions.push(eq(workOrders.crewId, filters.crewId));
  const rows = await db
    .select({ order: workOrders, report: reports, crewName: users.name })
    .from(workOrders)
    .innerJoin(reports, eq(reports.id, workOrders.reportId))
    .leftJoin(users, eq(users.id, workOrders.crewId))
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(workOrders.createdAt))
    .limit(filters.limit ?? 200);
  return rows.map((r) => ({
    ...r.order,
    crewName: r.crewName ?? null,
    reportReference: r.report.reference,
    reportRoad: r.report.roadName,
    reportZone: r.report.zone,
    reportSeverity: r.report.severity,
    reportDamageType: r.report.damageType,
    reportLatitude: r.report.latitude,
    reportLongitude: r.report.longitude,
  }));
}

export async function getWorkOrder(id: number) {
  const rows = await db
    .select({ order: workOrders, report: reports, crewName: users.name })
    .from(workOrders)
    .innerJoin(reports, eq(reports.id, workOrders.reportId))
    .leftJoin(users, eq(users.id, workOrders.crewId))
    .where(eq(workOrders.id, id))
    .limit(1);
  const found = rows[0];
  if (!found) return null;
  const log = await db
    .select()
    .from(workOrderUpdates)
    .where(eq(workOrderUpdates.workOrderId, id))
    .orderBy(desc(workOrderUpdates.createdAt));
  return {
    order: { ...found.order, crewName: found.crewName ?? null },
    report: found.report,
    log,
  };
}

export async function crewList() {
  return db
    .select({ id: users.id, name: users.name, email: users.email, zone: users.zone, organisation: users.organisation })
    .from(users)
    .where(eq(users.role, "crew"))
    .orderBy(users.name);
}

export async function zones() {
  const rows = await db
    .selectDistinct({ zone: reports.zone })
    .from(reports)
    .where(sql`${reports.zone} is not null`);
  return rows.map((r) => r.zone).filter((z): z is string => Boolean(z)).sort();
}

export async function publicCounts() {
  const rows = await db
    .select({
      total: count(),
      resolved: sql<number>`count(*) filter (where ${reports.status} in ('resolved','closed'))`,
      open: sql<number>`count(*) filter (where ${reports.status} not in ('resolved','closed','rejected'))`,
    })
    .from(reports)
    .where(gte(reports.createdAt, new Date(Date.now() - 365 * 86400000)));
  const row = rows[0];
  return {
    total: Number(row?.total ?? 0),
    resolved: Number(row?.resolved ?? 0),
    open: Number(row?.open ?? 0),
  };
}
