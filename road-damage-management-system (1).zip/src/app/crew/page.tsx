import Link from "next/link";
import { redirect } from "next/navigation";
import SiteHeader from "@/components/SiteHeader";
import { EmptyState, ProgressBar, SeverityBadge, StatCard, WorkOrderBadge } from "@/components/ui";
import { getCurrentUser, roleHomePath } from "@/lib/auth";
import { WORK_SCOPE_LABEL, type WorkScope } from "@/lib/constants";
import { coord, formatDateTime, money } from "@/lib/format";
import { listWorkOrders } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function CrewPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.role !== "crew") redirect(roleHomePath(user.role));

  const orders = await listWorkOrders({ crewId: user.id, limit: 100 });
  const scheduled = orders.filter((o) => o.status === "scheduled").length;
  const active = orders.filter((o) => o.status === "in_progress").length;
  const done = orders.filter((o) => o.status === "completed").length;

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-10 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-amber-600">Maintenance crew</p>
            <h1 className="mt-2 text-3xl font-extrabold tracking-tight">{user.name}</h1>
            <p className="mt-1 text-sm text-asphalt-500">
              {user.organisation ?? "Field crew"} · assigned zone {user.zone ?? "—"} · {orders.length} job
              {orders.length === 1 ? "" : "s"} allocated
            </p>
          </div>
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-3">
          <StatCard label="Scheduled" value={scheduled} hint="Ready to start" icon="🗓️" />
          <StatCard label="In progress" value={active} hint="Crew on site" icon="🚧" />
          <StatCard label="Completed" value={done} hint="Repairs finished" tone="text-emerald-600" icon="✅" />
        </div>

        <h2 className="mt-10 text-lg font-bold tracking-tight">My job list</h2>
        <div className="mt-4 space-y-4">
          {orders.length === 0 && (
            <EmptyState
              title="No work orders assigned yet"
              description="Once the road authority dispatches a crew, the job appears here with location, materials and instructions."
            />
          )}
          {orders.map((wo) => (
            <Link key={wo.id} href={`/crew/${wo.id}`} className="card block p-5 hover:border-amber-300">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-mono text-xs font-bold text-asphalt-700">{wo.code}</span>
                <WorkOrderBadge status={wo.status} />
                <SeverityBadge severity={wo.reportSeverity} />
                <span className="ml-auto text-xs text-asphalt-500">{formatDateTime(wo.scheduledStart)}</span>
              </div>
              <p className="mt-2 text-lg font-semibold text-asphalt-900">{wo.title}</p>
              <p className="text-sm text-asphalt-500">
                {WORK_SCOPE_LABEL[wo.scope as WorkScope] ?? wo.scope} · {wo.reportRoad}
                {wo.reportZone ? ` · ${wo.reportZone}` : ""} · {coord(wo.reportLatitude)},{" "}
                {coord(wo.reportLongitude)}
              </p>
              <div className="mt-3">
                <ProgressBar value={wo.progress} tone={wo.progress === 100 ? "bg-emerald-500" : "bg-amber-500"} />
                <div className="mt-1 flex justify-between text-xs text-asphalt-500">
                  <span>{wo.progress}% complete</span>
                  <span>materials budget {money(wo.estimatedCost)}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </main>
    </div>
  );
}
