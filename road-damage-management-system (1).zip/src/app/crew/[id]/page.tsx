import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { WorkOrderProgressForm } from "@/components/WorkOrderForms";
import SiteHeader from "@/components/SiteHeader";
import TileMap from "@/components/TileMap";
import { ProgressBar, SeverityBadge, StatusBadge, WorkOrderBadge } from "@/components/ui";
import { getCurrentUser, roleHomePath } from "@/lib/auth";
import { DAMAGE_TYPE_LABEL, WORK_SCOPE_LABEL, type DamageType, type WorkScope } from "@/lib/constants";
import { coord, formatDateTime, money } from "@/lib/format";
import { getWorkOrder } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function CrewJobPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.role !== "crew") redirect(roleHomePath(user.role));

  const data = await getWorkOrder(Number(id));
  if (!data) notFound();
  if (data.order.crewId !== user.id) {
    return (
      <div className="flex min-h-screen flex-col">
        <SiteHeader />
        <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-16 text-center">
          <h1 className="text-2xl font-bold">Not your job</h1>
          <p className="mt-2 text-sm text-asphalt-500">
            Work order {data.order.code} is assigned to another crew.
          </p>
          <Link href="/crew" className="btn btn-primary mt-6">Back to my jobs</Link>
        </main>
      </div>
    );
  }

  const { order, report, log } = data;

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-8 sm:px-6">
        <Link href="/crew" className="text-sm font-semibold text-asphalt-500 hover:underline">
          ← Back to my jobs
        </Link>
        <div className="mt-3 flex flex-wrap items-center gap-3">
          <h1 className="font-mono text-2xl font-extrabold tracking-tight">{order.code}</h1>
          <WorkOrderBadge status={order.status} />
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-[1.3fr_1fr]">
          <div className="space-y-6">
            <div className="card p-5">
              <h2 className="text-lg font-bold">{order.title}</h2>
              <p className="mt-1 text-sm text-asphalt-500">
                {WORK_SCOPE_LABEL[order.scope as WorkScope] ?? order.scope}
              </p>
              {order.description && (
                <p className="mt-3 text-sm leading-relaxed text-asphalt-700">{order.description}</p>
              )}
              {order.materials && (
                <p className="mt-3 rounded-lg border border-asphalt-200 bg-asphalt-50 p-3 text-sm text-asphalt-700">
                  <strong>Materials:</strong> {order.materials}
                </p>
              )}
              <dl className="mt-4 grid grid-cols-2 gap-4 border-t border-asphalt-100 pt-4 text-sm sm:grid-cols-3">
                <div>
                  <dt className="text-xs uppercase tracking-wide text-asphalt-500">Scheduled start</dt>
                  <dd className="font-medium">{formatDateTime(order.scheduledStart)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-asphalt-500">Scheduled finish</dt>
                  <dd className="font-medium">{formatDateTime(order.scheduledEnd)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-asphalt-500">Materials budget</dt>
                  <dd className="font-medium">{money(order.estimatedCost)}</dd>
                </div>
              </dl>
              <div className="mt-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-semibold text-asphalt-800">Progress</span>
                  <span className="tabular-nums text-asphalt-500">{order.progress}%</span>
                </div>
                <div className="mt-2">
                  <ProgressBar value={order.progress} tone={order.progress === 100 ? "bg-emerald-500" : "bg-amber-500"} />
                </div>
              </div>
            </div>

            <WorkOrderProgressForm id={order.id} status={order.status} progress={order.progress} />

            <div className="card p-5">
              <h2 className="text-lg font-bold">Previous updates</h2>
              <ol className="mt-4 space-y-4">
                {log.map((entry) => (
                  <li key={entry.id} className="relative pl-6">
                    <span className="absolute left-0 top-1.5 h-3 w-3 rounded-full bg-sky-500 ring-2 ring-white" />
                    <p className="text-sm text-asphalt-800">{entry.message}</p>
                    <p className="mt-0.5 text-xs text-asphalt-500">
                      {entry.authorName} · {entry.progress}% · {formatDateTime(entry.createdAt)}
                    </p>
                  </li>
                ))}
                {log.length === 0 && <li className="text-sm text-asphalt-500">No updates yet.</li>}
              </ol>
            </div>
          </div>

          <div className="space-y-6">
            <div className="card overflow-hidden">
              <TileMap
                height={240}
                zoom={15}
                center={{ lat: Number(report.latitude), lng: Number(report.longitude) }}
                markers={[
                  {
                    lat: Number(report.latitude),
                    lng: Number(report.longitude),
                    label: report.roadName,
                    tone: order.status === "completed" ? "emerald" : "amber",
                  },
                ]}
              />
              <div className="p-4">
                <p className="text-xs uppercase tracking-wide text-asphalt-500">Job site</p>
                <p className="font-mono text-sm font-semibold">
                  {coord(report.latitude)}, {coord(report.longitude)}
                </p>
                <a
                  className="mt-2 inline-block text-xs font-semibold text-amber-700 hover:underline"
                  href={`https://www.openstreetmap.org/?mlat=${Number(report.latitude)}&mlon=${Number(report.longitude)}#map=17/${Number(report.latitude)}/${Number(report.longitude)}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  Navigate with OpenStreetMap →
                </a>
              </div>
            </div>

            <div className="card p-5">
              <p className="text-xs font-bold uppercase tracking-wide text-asphalt-500">Source complaint</p>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                <Link href={`/reports/${report.reference}`} className="font-mono text-xs font-bold text-amber-700 hover:underline">
                  {report.reference}
                </Link>
                <StatusBadge status={report.status} />
                <SeverityBadge severity={report.severity} />
              </div>
              <p className="mt-3 font-semibold text-asphalt-900">{report.title}</p>
              <p className="mt-1 text-sm text-asphalt-500">
                {DAMAGE_TYPE_LABEL[report.damageType as DamageType] ?? report.damageType} · {report.roadName}
                {report.landmark ? ` · near ${report.landmark}` : ""}
              </p>
              <p className="mt-2 text-sm text-asphalt-700">{report.description}</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
