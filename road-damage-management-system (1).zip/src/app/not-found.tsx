import Link from "next/link";
import SiteHeader from "@/components/SiteHeader";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto flex w-full max-w-3xl flex-1 flex-col items-center justify-center px-4 py-20 text-center">
        <span className="text-5xl">🚧</span>
        <h1 className="mt-4 text-3xl font-extrabold tracking-tight">Road closed</h1>
        <p className="mt-2 max-w-md text-sm text-asphalt-500">
          We could not find the page or report you were looking for. Check the reference code, or
          browse the live road damage reports.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Link href="/" className="btn btn-primary">Back to home</Link>
          <Link href="/reports" className="btn btn-ghost">Browse live reports</Link>
          <Link href="/track" className="btn btn-ghost">Track a report</Link>
        </div>
      </main>
    </div>
  );
}
