import Link from "next/link";
import { redirect } from "next/navigation";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import { DamageChip, EmptyState, SeverityBadge, StatusBadge } from "@/components/ui";
import { getCurrentUser, roleHomePath } from "@/lib/auth";
import { formatDate, relativeTime } from "@/lib/format";
import { listReports } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function MyReportsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.role === "authority") redirect(roleHomePath("authority"));
  if (user.role === "crew") redirect(roleHomePath("crew"));

  const rows = await listReports({ reporterId: user.id, limit: 100 });
  const open = rows.filter((r) => !["resolved", "closed", "rejected"].includes(r.status)).length;
  const resolved = rows.filter((r) => ["resolved", "closed"].includes(r.status)).length;

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-10 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight">My reports</h1>
            <p className="mt-1 text-sm text-asphalt-500">
              {rows.length} complaint{rows.length === 1 ? "" : "s"} submitted · {open} open · {resolved} repaired
            </p>
          </div>
          <Link href="/report" className="btn btn-accent">
            Report new damage
          </Link>
        </div>

        <div className="mt-8">
          {rows.length === 0 ? (
            <EmptyState
              title="You have not reported any damage yet"
              description="Spot a pothole, crack or damaged surface? Submit a report and follow its repair here."
              action={
                <Link href="/report" className="btn btn-accent mt-2">
                  Submit a report
                </Link>
              }
            />
          ) : (
            <div className="space-y-3">
              {rows.map((r) => (
                <Link
                  key={r.id}
                  href={`/reports/${r.reference}`}
                  className="card flex flex-wrap items-center gap-3 p-4 transition hover:border-amber-300"
                >
                  <div className="min-w-[220px] flex-1">
                    <p className="font-semibold text-asphalt-900">{r.title}</p>
                    <p className="mt-0.5 text-sm text-asphalt-500">
                      {r.roadName} · logged {formatDate(r.createdAt)} ({relativeTime(r.createdAt)})
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <DamageChip type={r.damageType} />
                    <SeverityBadge severity={r.severity} />
                    <StatusBadge status={r.status} />
                    <span className="font-mono text-xs text-asphalt-400">{r.reference}</span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
