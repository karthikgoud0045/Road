import Link from "next/link";
import { notFound } from "next/navigation";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import TileMap from "@/components/TileMap";
import { CommentForm, SupportButton } from "@/components/ReportInteractions";
import { DamageChip, ProgressBar, SeverityBadge, StatusBadge, WorkOrderBadge } from "@/components/ui";
import { getCurrentUser } from "@/lib/auth";
import { DAMAGE_TYPE_LABEL, WORK_SCOPE_LABEL, type DamageType, type WorkScope } from "@/lib/constants";
import { coord, formatDateTime, money, relativeTime, slaDaysLeft } from "@/lib/format";
import { getReportByReference } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function ReportDetailPage({
  params,
}: {
  params: Promise<{ reference: string }>;
}) {
  const { reference } = await params;
  const result = await getReportByReference(decodeURIComponent(reference).toUpperCase());
  if (!result) notFound();

  const user = await getCurrentUser();
  const isAuthority = user?.role === "authority";
  const { report, timeline, workOrders } = result;
  const slaLeft = slaDaysLeft(report.createdAt, report.severity);
  const resolved = report.status === "resolved" || report.status === "closed";

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 sm:px-6">
        <Link href="/reports" className="text-sm font-semibold text-asphalt-500 hover:underline">
          ← Back to all reports
        </Link>

        <div className="mt-4 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
          <div className="space-y-6">
            <div className="card p-6">
              <div className="flex flex-wrap items-center gap-2">
                <DamageChip type={report.damageType} />
                <SeverityBadge severity={report.severity} />
                <StatusBadge status={report.status} />
                <span className="ml-auto font-mono text-xs text-asphalt-400">{report.reference}</span>
              </div>
              <h1 className="mt-3 text-2xl font-extrabold tracking-tight">{report.title}</h1>
              <p className="mt-1 text-sm text-asphalt-500">
                {report.roadName}
                {report.landmark ? ` · near ${report.landmark}` : ""}
                {report.zone ? ` · ${report.zone}` : ""}
              </p>
              <p className="mt-4 text-sm leading-relaxed text-asphalt-700">{report.description}</p>

              {report.photoUrl && (
                <img
                  src={report.photoUrl}
                  alt="Reported road damage"
                  className="mt-4 max-h-80 w-full rounded-xl border border-asphalt-200 object-cover"
                />
              )}

              <dl className="mt-5 grid grid-cols-2 gap-4 border-t border-asphalt-100 pt-4 text-sm sm:grid-cols-4">
                <div>
                  <dt className="text-xs uppercase tracking-wide text-asphalt-500">Reported by</dt>
                  <dd className="font-medium">{report.reporterName}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-asphalt-500">Logged</dt>
                  <dd className="font-medium">{formatDateTime(report.createdAt)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-asphalt-500">Damage type</dt>
                  <dd className="font-medium">
                    {DAMAGE_TYPE_LABEL[report.damageType as DamageType] ?? report.damageType}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-asphalt-500">
                    {resolved ? "Resolved" : "SLA target"}
                  </dt>
                  <dd className={`font-medium ${slaLeft < 0 && !resolved ? "text-rose-600" : ""}`}>
                    {resolved
                      ? formatDateTime(report.resolvedAt)
                      : `${slaLeft < 0 ? `${Math.abs(slaLeft)}d overdue` : `${slaLeft}d remaining`}`}
                  </dd>
                </div>
              </dl>

              <div className="mt-5 flex flex-wrap gap-3">
                <SupportButton reference={report.reference} initial={report.supports} disabled={!user} />
                {isAuthority && (
                  <Link href={`/dashboard/reports?ref=${report.reference}`} className="btn btn-accent">
                    Review in authority desk
                  </Link>
                )}
                {user?.role === "crew" && <Link href="/crew" className="btn btn-ghost">My crew jobs</Link>}
              </div>
              {!user && (
                <p className="mt-2 text-xs text-asphalt-500">
                  <Link href="/login" className="font-semibold text-amber-700 hover:underline">
                    Sign in
                  </Link>{" "}
                  to support this report or post an update.
                </p>
              )}
            </div>

            <div className="card p-6">
              <h2 className="text-lg font-bold">Complaint timeline</h2>
              <p className="mt-1 text-sm text-asphalt-500">
                Every status change and note recorded against this report.
              </p>
              {user && (
                <div className="mt-4 rounded-xl border border-asphalt-200 bg-asphalt-50/60 p-4">
                  <CommentForm reference={report.reference} />
                </div>
              )}
              <ol className="mt-6 space-y-5">
                {[...timeline]
                  .filter((t) => t.isPublic || isAuthority)
                  .reverse()
                  .map((t) => (
                    <li key={t.id} className="relative pl-6">
                      <span
                        className={`absolute left-0 top-1.5 h-3 w-3 rounded-full ring-2 ring-white ${
                          t.statusTo === "resolved" || t.statusTo === "closed"
                            ? "bg-emerald-500"
                            : t.statusTo === "rejected"
                              ? "bg-asphalt-400"
                              : t.authorRole === "crew"
                                ? "bg-sky-500"
                                : "bg-amber-500"
                        }`}
                      />
                      {t.statusTo && <StatusBadge status={t.statusTo} />}
                      <p className="mt-1.5 text-sm leading-relaxed text-asphalt-800">{t.message}</p>
                      <p className="mt-1 text-xs text-asphalt-500">
                        {t.authorName}
                        {t.authorRole === "authority" && !t.isPublic ? " · internal note" : ""} ·{" "}
                        {formatDateTime(t.createdAt)} · {relativeTime(t.createdAt)}
                      </p>
                    </li>
                  ))}
              </ol>
            </div>
          </div>

          <div className="space-y-6">
            <div className="card overflow-hidden">
              <TileMap
                height={280}
                zoom={15}
                center={{ lat: Number(report.latitude), lng: Number(report.longitude) }}
                markers={[
                  {
                    lat: Number(report.latitude),
                    lng: Number(report.longitude),
                    label: report.roadName,
                    tone: resolved ? "emerald" : "amber",
                  },
                ]}
              />
              <div className="p-4">
                <p className="text-xs uppercase tracking-wide text-asphalt-500">Exact coordinates</p>
                <p className="font-mono text-sm font-semibold text-asphalt-900">
                  {coord(report.latitude)}, {coord(report.longitude)}
                </p>
                <a
                  className="mt-2 inline-block text-xs font-semibold text-amber-700 hover:underline"
                  href={`https://www.openstreetmap.org/?mlat=${Number(report.latitude)}&mlon=${Number(report.longitude)}#map=17/${Number(report.latitude)}/${Number(report.longitude)}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  Open location in OpenStreetMap →
                </a>
              </div>
            </div>

            <div className="card p-5">
              <h2 className="text-lg font-bold">Maintenance work orders</h2>
              {workOrders.length === 0 ? (
                <p className="mt-2 text-sm text-asphalt-500">
                  {resolved
                    ? "Repair completed through an archived work order."
                    : "No work order yet. The road authority creates one after verifying the complaint."}
                </p>
              ) : (
                <ul className="mt-4 space-y-4">
                  {workOrders.map((wo) => (
                    <li key={wo.id} className="rounded-xl border border-asphalt-200 p-4">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-xs font-bold text-asphalt-700">{wo.code}</span>
                        <WorkOrderBadge status={wo.status} />
                      </div>
                      <p className="mt-2 text-sm font-semibold text-asphalt-900">
                        {WORK_SCOPE_LABEL[wo.scope as WorkScope] ?? wo.scope}
                      </p>
                      <div className="mt-2">
                        <ProgressBar value={wo.progress} tone={wo.progress === 100 ? "bg-emerald-500" : "bg-amber-500"} />
                        <p className="mt-1 text-xs text-asphalt-500">{wo.progress}% complete</p>
                      </div>
                      <dl className="mt-3 space-y-1 text-xs text-asphalt-600">
                        <div className="flex justify-between gap-2">
                          <dt>Crew</dt>
                          <dd className="font-medium">{wo.crewName ?? "Unassigned"}</dd>
                        </div>
                        <div className="flex justify-between gap-2">
                          <dt>Scheduled</dt>
                          <dd className="font-medium">{formatDateTime(wo.scheduledStart)}</dd>
                        </div>
                        <div className="flex justify-between gap-2">
                          <dt>Estimated cost</dt>
                          <dd className="font-medium">{money(wo.estimatedCost)}</dd>
                        </div>
                        <div className="flex justify-between gap-2">
                          <dt>Actual cost</dt>
                          <dd className="font-medium">{money(wo.actualCost)}</dd>
                        </div>
                      </dl>
                      <Link
                        href={`/dashboard/work-orders/${wo.id}`}
                        className="mt-3 inline-block text-xs font-semibold text-amber-700 hover:underline"
                      >
                        View work order log →
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
