import Link from "next/link";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import TileMap, { type MapMarker } from "@/components/TileMap";
import { DamageChip, EmptyState, SeverityBadge, StatusBadge } from "@/components/ui";
import {
  DAMAGE_TYPES,
  DAMAGE_TYPE_LABEL,
  REPORT_STATUSES,
  REPORT_STATUS_LABEL,
  SEVERITIES,
  SEVERITY_LABEL,
  isReportStatus,
} from "@/lib/constants";
import { relativeTime } from "@/lib/format";
import { listReports, zones } from "@/lib/queries";

export const dynamic = "force-dynamic";

type Search = {
  q?: string;
  status?: string;
  damageType?: string;
  severity?: string;
  zone?: string;
  view?: string;
};

export default async function ReportsPage({
  searchParams,
}: {
  searchParams: Promise<Search>;
}) {
  const sp = await searchParams;
  const statusFilter = sp.status && isReportStatus(sp.status) ? sp.status : "";
  const [rows, zoneList] = await Promise.all([
    listReports({
      q: sp.q,
      status: statusFilter,
      damageType: sp.damageType,
      severity: sp.severity,
      zone: sp.zone,
      limit: 300,
    }),
    zones(),
  ]);

  const markers: MapMarker[] = rows
    .filter((r) => Number.isFinite(Number(r.latitude)))
    .slice(0, 120)
    .map((r) => ({
      lat: Number(r.latitude),
      lng: Number(r.longitude),
      label: `${r.reference} · ${DAMAGE_TYPE_LABEL[r.damageType as keyof typeof DAMAGE_TYPE_LABEL] ?? r.damageType}`,
      tone:
        r.severity === "critical"
          ? "rose"
          : r.status === "resolved" || r.status === "closed"
            ? "emerald"
            : r.status === "in_progress"
              ? "sky"
              : "amber",
    }));

  const center =
    markers.length > 0
      ? {
          lat: markers.reduce((s, m) => s + m.lat, 0) / markers.length,
          lng: markers.reduce((s, m) => s + m.lng, 0) / markers.length,
        }
      : undefined;

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-10 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight">Live road damage reports</h1>
            <p className="mt-1 text-sm text-asphalt-500">
              {rows.length} report{rows.length === 1 ? "" : "s"} matching your filters · open data for
              citizens and road authorities.
            </p>
          </div>
          <div className="flex gap-2">
            <Link href="/report" className="btn btn-accent">
              Report damage
            </Link>
            <Link href="/track" className="btn btn-ghost">
              Track a report
            </Link>
          </div>
        </div>

        <form
          action="/reports"
          method="get"
          className="card mt-6 grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-6 lg:items-end"
        >
          <div className="lg:col-span-2">
            <label className="label" htmlFor="q">Search</label>
            <input id="q" name="q" defaultValue={sp.q ?? ""} className="field" placeholder="road, landmark, reference…" />
          </div>
          <div>
            <label className="label" htmlFor="status">Status</label>
            <select id="status" name="status" defaultValue={statusFilter} className="field">
              <option value="">All</option>
              {REPORT_STATUSES.map((s) => (
                <option key={s} value={s}>{REPORT_STATUS_LABEL[s]}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="damageType">Damage type</label>
            <select id="damageType" name="damageType" defaultValue={sp.damageType ?? ""} className="field">
              <option value="">All</option>
              {DAMAGE_TYPES.map((t) => (
                <option key={t} value={t}>{DAMAGE_TYPE_LABEL[t]}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="severity">Severity</label>
            <select id="severity" name="severity" defaultValue={sp.severity ?? ""} className="field">
              <option value="">All</option>
              {SEVERITIES.map((s) => (
                <option key={s} value={s}>{SEVERITY_LABEL[s]}</option>
              ))}
            </select>
          </div>
          <div className="flex gap-2">
            <div className="flex-1">
              <label className="label" htmlFor="zone">Zone</label>
              <select id="zone" name="zone" defaultValue={sp.zone ?? ""} className="field">
                <option value="">All</option>
                {zoneList.map((z) => (
                  <option key={z} value={z}>{z}</option>
                ))}
              </select>
            </div>
          </div>
          <div className="flex gap-2 sm:col-span-2 lg:col-span-6">
            <button type="submit" className="btn btn-primary">Apply filters</button>
            <Link href="/reports" className="btn btn-ghost">Reset</Link>
          </div>
        </form>

        <div className="mt-6">
          <TileMap
            height={360}
            zoom={12}
            center={center}
            markers={markers}
          />
        </div>

        <div className="mt-8">
          {rows.length === 0 ? (
            <EmptyState
              title="No reports match these filters"
              description="Try widening the filters, or be the first to report damage on this road."
              action={
                <Link href="/report" className="btn btn-accent mt-2">
                  Submit a report
                </Link>
              }
            />
          ) : (
            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
              {rows.map((r) => (
                <Link
                  key={r.id}
                  href={`/reports/${r.reference}`}
                  className="card flex flex-col p-4 transition hover:border-amber-300"
                >
                  <div className="flex flex-wrap items-center gap-2">
                    <DamageChip type={r.damageType} />
                    <SeverityBadge severity={r.severity} />
                    <StatusBadge status={r.status} />
                  </div>
                  <p className="mt-3 font-semibold text-asphalt-900">{r.title}</p>
                  <p className="mt-1 text-sm text-asphalt-500">
                    {r.roadName}
                    {r.zone ? ` · ${r.zone}` : ""}
                  </p>
                  <p className="mt-2 line-clamp-2 text-sm text-asphalt-600">{r.description}</p>
                  <div className="mt-3 flex items-center justify-between border-t border-asphalt-100 pt-3 text-xs text-asphalt-500">
                    <span className="font-mono">{r.reference}</span>
                    <span>
                      👍 {r.supports} · {relativeTime(r.createdAt)}
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
