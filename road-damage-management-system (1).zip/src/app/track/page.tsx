import Link from "next/link";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import { DamageChip, EmptyState, SeverityBadge, StatusBadge } from "@/components/ui";
import { coord, formatDateTime, relativeTime } from "@/lib/format";
import { getReportByReference } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function TrackPage({
  searchParams,
}: {
  searchParams: Promise<{ ref?: string }>;
}) {
  const { ref } = await searchParams;
  const query = (ref ?? "").trim().toUpperCase();
  const result = query ? await getReportByReference(query) : null;

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-4xl flex-1 px-4 py-10 sm:px-6">
        <h1 className="text-3xl font-extrabold tracking-tight">Track a report</h1>
        <p className="mt-2 text-sm text-asphalt-500">
          Enter the reference code you received when submitting the complaint (for example{" "}
          <span className="font-mono font-semibold">RD-2026-0001</span>).
        </p>

        <form action="/track" method="get" className="card mt-6 flex flex-wrap gap-3 p-4">
          <input
            name="ref"
            defaultValue={query}
            placeholder="RD-2026-0001"
            className="field flex-1 font-mono uppercase"
            aria-label="Reference code"
          />
          <button type="submit" className="btn btn-primary px-6">
            Track
          </button>
        </form>

        {query && !result && (
          <div className="mt-8">
            <EmptyState
              title="No report found"
              description={`We could not find a report with reference “${query}”. Check the code and try again, or browse the live reports.`}
              action={
                <Link href="/reports" className="btn btn-ghost mt-2">
                  Browse reports
                </Link>
              }
            />
          </div>
        )}

        {result && (
          <div className="mt-8 space-y-6">
            <div className="card p-6">
              <div className="flex flex-wrap items-center gap-2">
                <DamageChip type={result.report.damageType} />
                <SeverityBadge severity={result.report.severity} />
                <StatusBadge status={result.report.status} />
                <span className="ml-auto font-mono text-xs text-asphalt-400">{result.report.reference}</span>
              </div>
              <h2 className="mt-3 text-xl font-bold">{result.report.title}</h2>
              <p className="mt-1 text-sm text-asphalt-500">
                {result.report.roadName}
                {result.report.landmark ? ` · ${result.report.landmark}` : ""} ·{" "}
                {coord(result.report.latitude)}, {coord(result.report.longitude)}
              </p>
              <p className="mt-4 text-sm leading-relaxed text-asphalt-700">{result.report.description}</p>
              <div className="mt-5 flex flex-wrap gap-3">
                <Link href={`/reports/${result.report.reference}`} className="btn btn-primary">
                  Open full report
                </Link>
              </div>
            </div>

            <div className="card p-6">
              <h3 className="text-sm font-bold uppercase tracking-wide text-asphalt-500">
                Complaint history
              </h3>
              <ol className="mt-4 space-y-4">
                {result.timeline
                  .filter((t) => t.isPublic)
                  .map((t) => (
                    <li key={t.id} className="flex gap-3">
                      <span className="mt-1 h-2.5 w-2.5 shrink-0 rounded-full bg-amber-500" />
                      <div>
                        <p className="text-sm text-asphalt-800">{t.message}</p>
                        <p className="mt-0.5 text-xs text-asphalt-500">
                          {t.authorName} · {formatDateTime(t.createdAt)} ({relativeTime(t.createdAt)})
                        </p>
                      </div>
                    </li>
                  ))}
              </ol>
            </div>
          </div>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}
