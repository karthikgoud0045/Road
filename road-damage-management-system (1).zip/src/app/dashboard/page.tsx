import Link from "next/link";
import TileMap, { type MapMarker } from "@/components/TileMap";
import {
  BarList,
  DamageChip,
  EmptyState,
  ReferenceLink,
  SectionHeading,
  SeverityBadge,
  StatCard,
  StatusBadge,
  WorkOrderBadge,
} from "@/components/ui";
import { DAMAGE_TYPE_LABEL, REPORT_STATUS_LABEL, SEVERITY_LABEL, type DamageType } from "@/lib/constants";
import { daysSince, relativeTime, slaDaysLeft } from "@/lib/format";
import { dashboardStats, listReports, listWorkOrders, overdueReports, recentActivity } from "@/lib/queries";

export const dynamic = "force-dynamic";

const SEVERITY_BAR_TONE: Record<string, string> = {
  low: "bg-teal-500",
  medium: "bg-amber-500",
  high: "bg-orange-500",
  critical: "bg-red-600",
};

export default async function DashboardPage() {
  const [stats, overdue, activity, openOrders, priorityQueue] = await Promise.all([
    dashboardStats(),
    overdueReports(6),
    recentActivity(8),
    listWorkOrders({ limit: 6 }),
    listReports({ limit: 400 }),
  ]);

  const openReports = priorityQueue.filter(
    (r) => !["resolved", "closed", "rejected"].includes(r.status),
  );
  const topPriority = openReports
    .map((r) => ({ ...r, score: daysSince(r.createdAt) * 2 + (r.severity === "critical" ? 40 : r.severity === "high" ? 25 : r.severity === "medium" ? 12 : 5) }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 6);

  const markers: MapMarker[] = openReports.slice(0, 120).map((r) => ({
    lat: Number(r.latitude),
    lng: Number(r.longitude),
    label: r.reference,
    tone: r.severity === "critical" ? "rose" : r.severity === "high" ? "amber" : "sky",
  }));
  const center = markers.length
    ? {
        lat: markers.reduce((s, m) => s + m.lat, 0) / markers.length,
        lng: markers.reduce((s, m) => s + m.lng, 0) / markers.length,
      }
    : undefined;

  const resolutionRate =
    stats.total > 0 ? Math.round(((stats.resolved / stats.total) * 100)) : 0;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight">Road maintenance overview</h1>
        <p className="mt-1 text-sm text-asphalt-500">
          Live picture of citizen complaints, authority triage and repair progress.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Open complaints" value={stats.open} hint={`${stats.total} logged in total`} icon="📬" />
        <StatCard
          label="Critical backlog"
          value={stats.critical}
          hint="Unresolved critical severity"
          tone={stats.critical > 0 ? "text-rose-600" : "text-emerald-600"}
          icon="⚠️"
        />
        <StatCard label="Repairs in progress" value={stats.inProgress} hint="Crews actively on site" icon="🚧" />
        <StatCard
          label="Resolution rate"
          value={`${resolutionRate}%`}
          hint={stats.avgResolutionDays ? `Avg ${stats.avgResolutionDays} days to fix` : "No completed repairs yet"}
          tone="text-emerald-600"
          icon="✅"
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="card p-5">
          <SectionHeading title="Complaints by damage type" description="Where most damage is being reported" />
          <div className="mt-4">
            <BarList
              items={stats.byType.slice(0, 8).map((t) => ({
                label: DAMAGE_TYPE_LABEL[t.damageType as DamageType] ?? t.damageType,
                value: t.total,
                tone: "bg-asphalt-800",
              }))}
            />
          </div>
        </div>

        <div className="card p-5">
          <SectionHeading title="Pipeline & severity" description="Complaints at each stage" />
          <div className="mt-4 grid gap-6 sm:grid-cols-2">
            <BarList
              items={stats.bySeverity.map((s) => ({
                label: SEVERITY_LABEL[s.severity],
                value: s.total,
                tone: SEVERITY_BAR_TONE[s.severity],
              }))}
            />
            <BarList
              items={stats.byStatus.map((s) => ({
                label: REPORT_STATUS_LABEL[s.status as keyof typeof REPORT_STATUS_LABEL] ?? s.status,
                value: s.total,
                tone: "bg-asphalt-500",
              }))}
            />
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.35fr_1fr]">
        <div className="card overflow-hidden">
          <div className="p-5 pb-0">
            <SectionHeading
              title="Open damage map"
              description="Unresolved reports still waiting for a repair"
              action={
                <Link href="/reports" className="text-sm font-semibold text-amber-700 hover:underline">
                  Full map →
                </Link>
              }
            />
          </div>
          <div className="p-5">
            <TileMap height={330} zoom={12} center={center} markers={markers} />
          </div>
        </div>

        <div className="card p-5">
          <SectionHeading title="Priority queue" description="Highest risk complaints first" />
          <ul className="mt-4 divide-y divide-asphalt-100">
            {topPriority.length === 0 && (
              <li className="py-4 text-sm text-asphalt-500">No open complaints. Great work! 🎉</li>
            )}
            {topPriority.map((r) => {
              const sla = slaDaysLeft(r.createdAt, r.severity);
              return (
                <li key={r.id} className="flex flex-wrap items-center gap-2 py-3">
                  <div className="min-w-[180px] flex-1">
                    <p className="text-sm font-semibold text-asphalt-900">{r.title}</p>
                    <p className="text-xs text-asphalt-500">
                      {r.roadName} · <ReferenceLink reference={r.reference} />
                    </p>
                  </div>
                  <DamageChip type={r.damageType} />
                  <SeverityBadge severity={r.severity} />
                  <span className={`text-xs font-semibold ${sla < 0 ? "text-rose-600" : "text-asphalt-500"}`}>
                    {sla < 0 ? `${Math.abs(sla)}d overdue` : `${sla}d left`}
                  </span>
                  <Link href={`/dashboard/reports?ref=${r.reference}`} className="btn btn-ghost text-xs">
                    Triage
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="card p-5">
          <SectionHeading
            title="SLA breaches"
            description="High / critical damage older than 5 days"
            action={
              <Link href="/dashboard/reports" className="text-sm font-semibold text-amber-700 hover:underline">
                Triage queue →
              </Link>
            }
          />
          <ul className="mt-4 space-y-3">
            {overdue.length === 0 && (
              <li className="text-sm text-asphalt-500">No high-severity complaints are breaching SLA.</li>
            )}
            {overdue.map((r) => (
              <li key={r.id} className="rounded-xl border border-rose-200 bg-rose-50/60 p-3">
                <div className="flex flex-wrap items-center gap-2">
                  <SeverityBadge severity={r.severity} />
                  <StatusBadge status={r.status} />
                  <span className="ml-auto font-mono text-[11px] text-asphalt-500">{r.reference}</span>
                </div>
                <p className="mt-2 text-sm font-semibold text-asphalt-900">{r.title}</p>
                <p className="text-xs text-asphalt-500">
                  {r.roadName} · waiting {daysSince(r.createdAt)} days
                </p>
              </li>
            ))}
          </ul>
        </div>

        <div className="card p-5">
          <SectionHeading title="Recent activity" description="Latest actions across the platform" />
          <ol className="mt-4 space-y-3">
            {activity.length === 0 && <li className="text-sm text-asphalt-500">No activity recorded yet.</li>}
            {activity.map((a) => (
              <li key={a.id} className="flex gap-3">
                <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-amber-500" />
                <div>
                  <p className="text-sm text-asphalt-800">{a.message}</p>
                  <p className="mt-0.5 text-xs text-asphalt-500">
                    {a.authorName} · <ReferenceLink reference={a.reference} /> · {relativeTime(a.createdAt)}
                  </p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </div>

      <div className="card p-5">
        <SectionHeading
          title="Maintenance work orders"
          description="Scheduled and active repair jobs"
          action={
            <Link href="/dashboard/work-orders" className="btn btn-primary text-xs">
              Manage work orders
            </Link>
          }
        />
        {openOrders.length === 0 ? (
          <div className="mt-4">
            <EmptyState
              title="No work orders yet"
              description="Verify a citizen complaint and dispatch a maintenance crew to create the first work order."
              action={
                <Link href="/dashboard/reports" className="btn btn-accent mt-2">
                  Open triage queue
                </Link>
              }
            />
          </div>
        ) : (
          <div className="mt-4 overflow-x-auto scroll-thin">
            <table className="w-full min-w-[640px] text-sm">
              <thead>
                <tr className="text-left text-xs uppercase tracking-wide text-asphalt-500">
                  <th className="pb-2">Code</th>
                  <th className="pb-2">Scope job</th>
                  <th className="pb-2">Crew</th>
                  <th className="pb-2">Status</th>
                  <th className="pb-2">Progress</th>
                  <th className="pb-2" />
                </tr>
              </thead>
              <tbody className="divide-y divide-asphalt-100">
                {openOrders.map((wo) => (
                  <tr key={wo.id}>
                    <td className="py-2.5 font-mono text-xs font-bold text-asphalt-700">{wo.code}</td>
                    <td className="py-2.5">{wo.title}</td>
                    <td className="py-2.5">{wo.crewName ?? "—"}</td>
                    <td className="py-2.5"><WorkOrderBadge status={wo.status} /></td>
                    <td className="py-2.5">{wo.progress}%</td>
                    <td className="py-2.5 text-right">
                      <Link href={`/dashboard/work-orders/${wo.id}`} className="text-xs font-semibold text-amber-700 hover:underline">
                        Open →
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
