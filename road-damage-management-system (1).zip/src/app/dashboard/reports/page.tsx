import Link from "next/link";
import TriagePanel from "@/components/TriagePanel";
import { DamageChip, SeverityBadge, StatusBadge } from "@/components/ui";
import {
  REPORT_STATUSES,
  REPORT_STATUS_LABEL,
  SEVERITIES,
  SEVERITY_LABEL,
} from "@/lib/constants";
import { coord, daysSince, formatDateTime, slaDaysLeft } from "@/lib/format";
import { listReports } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function TriagePage({
  searchParams,
}: {
  searchParams: Promise<{ ref?: string; status?: string; severity?: string; q?: string }>;
}) {
  const sp = await searchParams;
  const focus = (sp.ref ?? "").toUpperCase();

  const rows = await listReports({
    q: sp.q,
    status: sp.status,
    severity: sp.severity,
    limit: 120,
  });

  const ordered = focus
    ? [...rows].sort((a, b) => (a.reference === focus ? -1 : b.reference === focus ? 1 : 0))
    : rows;

  const open = rows.filter((r) => !["resolved", "closed", "rejected"].includes(r.status)).length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight">Complaint triage</h1>
        <p className="mt-1 text-sm text-asphalt-500">
          {rows.length} complaint{rows.length === 1 ? "" : "s"} shown · {open} still open · verify, grade
          and dispatch maintenance crews.
        </p>
      </div>

      <form action="/dashboard/reports" method="get" className="card grid gap-3 p-4 sm:grid-cols-4 sm:items-end">
        <div className="sm:col-span-2">
          <label className="label" htmlFor="q">Search</label>
          <input id="q" name="q" defaultValue={sp.q ?? ""} className="field" placeholder="reference, road, reporter…" />
        </div>
        <div>
          <label className="label" htmlFor="status">Status</label>
          <select id="status" name="status" defaultValue={sp.status ?? ""} className="field">
            <option value="">All statuses</option>
            {REPORT_STATUSES.map((s) => (
              <option key={s} value={s}>{REPORT_STATUS_LABEL[s]}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="label" htmlFor="severity">Severity</label>
          <select id="severity" name="severity" defaultValue={sp.severity ?? ""} className="field">
            <option value="">All severities</option>
            {SEVERITIES.map((s) => (
              <option key={s} value={s}>{SEVERITY_LABEL[s]}</option>
            ))}
          </select>
        </div>
        <div className="flex gap-2 sm:col-span-4">
          <button type="submit" className="btn btn-primary">Apply</button>
          <Link href="/dashboard/reports" className="btn btn-ghost">Reset</Link>
          <Link href="/dashboard/work-orders" className="btn btn-ghost">Work orders →</Link>
        </div>
      </form>

      <div className="space-y-4">
        {ordered.map((r) => {
          const sla = slaDaysLeft(r.createdAt, r.severity);
          const isFocus = r.reference === focus;
          return (
            <details key={r.id} open={isFocus} className="card overflow-hidden">
              <summary className="flex cursor-pointer flex-wrap items-center gap-2 bg-asphalt-50/50 px-4 py-3">
                <span className="font-mono text-xs font-bold text-asphalt-600">{r.reference}</span>
                <span className="min-w-[200px] flex-1 text-sm font-semibold text-asphalt-900">{r.title}</span>
                <DamageChip type={r.damageType} />
                <SeverityBadge severity={r.severity} />
                <StatusBadge status={r.status} />
                <span className={`text-xs font-semibold ${sla < 0 ? "text-rose-600" : "text-asphalt-500"}`}>
                  {["resolved", "closed", "rejected"].includes(r.status)
                    ? daysSince(r.createdAt) > 0
                      ? `closed in ${daysSince(r.createdAt)}d`
                      : "closed"
                    : sla < 0
                      ? `${Math.abs(sla)}d overdue`
                      : `${sla}d left`}
                </span>
              </summary>

              <div className="grid gap-5 p-4 lg:grid-cols-[1.3fr_1fr]">
                <div>
                  <p className="text-sm leading-relaxed text-asphalt-700">{r.description}</p>
                  <dl className="mt-4 grid grid-cols-2 gap-3 text-xs sm:grid-cols-3">
                    <div>
                      <dt className="uppercase tracking-wide text-asphalt-500">Road</dt>
                      <dd className="font-semibold text-asphalt-800">{r.roadName}</dd>
                    </div>
                    <div>
                      <dt className="uppercase tracking-wide text-asphalt-500">Zone</dt>
                      <dd className="font-semibold text-asphalt-800">{r.zone ?? "—"}</dd>
                    </div>
                    <div>
                      <dt className="uppercase tracking-wide text-asphalt-500">Landmark</dt>
                      <dd className="font-semibold text-asphalt-800">{r.landmark ?? "—"}</dd>
                    </div>
                    <div>
                      <dt className="uppercase tracking-wide text-asphalt-500">Reporter</dt>
                      <dd className="font-semibold text-asphalt-800">{r.reporterName}</dd>
                    </div>
                    <div>
                      <dt className="uppercase tracking-wide text-asphalt-500">Contact</dt>
                      <dd className="font-semibold text-asphalt-800">{r.reporterPhone ?? r.reporterEmail ?? "—"}</dd>
                    </div>
                    <div>
                      <dt className="uppercase tracking-wide text-asphalt-500">Coordinates</dt>
                      <dd className="font-mono font-semibold text-asphalt-800">
                        {coord(r.latitude)}, {coord(r.longitude)}
                      </dd>
                    </div>
                    <div>
                      <dt className="uppercase tracking-wide text-asphalt-500">Logged</dt>
                      <dd className="font-semibold text-asphalt-800">{formatDateTime(r.createdAt)}</dd>
                    </div>
                    <div>
                      <dt className="uppercase tracking-wide text-asphalt-500">Supporters</dt>
                      <dd className="font-semibold text-asphalt-800">👍 {r.supports}</dd>
                    </div>
                    <div>
                      <dt className="uppercase tracking-wide text-asphalt-500">Assigned crew</dt>
                      <dd className="font-semibold text-asphalt-800">{r.crewName ?? "Not assigned"}</dd>
                    </div>
                  </dl>
                  {r.photoUrl && (
                    <img src={r.photoUrl} alt="Damage photo" className="mt-4 max-h-52 rounded-lg border border-asphalt-200 object-cover" />
                  )}
                  <div className="mt-4 flex flex-wrap gap-2 text-xs">
                    <Link href={`/reports/${r.reference}`} className="btn btn-ghost">
                      Public page
                    </Link>
                    <Link
                      href={`/dashboard/work-orders?ref=${r.reference}`}
                      className="btn btn-accent"
                    >
                      🚧 Create work order
                    </Link>
                  </div>
                </div>

                <TriagePanel reference={r.reference} status={r.status} severity={r.severity} />
              </div>
            </details>
          );
        })}
        {rows.length === 0 && (
          <p className="card p-6 text-sm text-asphalt-500">No complaints match these filters.</p>
        )}
      </div>
    </div>
  );
}
