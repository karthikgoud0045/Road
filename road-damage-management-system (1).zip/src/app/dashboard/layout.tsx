import Link from "next/link";
import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import SiteHeader from "@/components/SiteHeader";
import { getCurrentUser } from "@/lib/auth";

const NAV = [
  { href: "/dashboard", label: "Overview", icon: "📊" },
  { href: "/dashboard/reports", label: "Complaint triage", icon: "🗂️" },
  { href: "/dashboard/work-orders", label: "Work orders", icon: "🚧" },
  { href: "/reports", label: "Public map", icon: "🗺️" },
];

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.role !== "authority") {
    redirect(user.role === "crew" ? "/crew" : "/my-reports");
  }

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <div className="mx-auto flex w-full max-w-7xl flex-1 gap-6 px-4 py-8 sm:px-6">
        <aside className="hidden w-56 shrink-0 lg:block">
          <nav className="card sticky top-24 p-3">
            <p className="px-2 pb-2 text-[10px] font-bold uppercase tracking-[0.16em] text-asphalt-400">
              Authority desk
            </p>
            <ul className="space-y-1">
              {NAV.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="flex items-center gap-2 rounded-lg px-2.5 py-2 text-sm font-medium text-asphalt-600 transition hover:bg-asphalt-100 hover:text-asphalt-900"
                  >
                    <span aria-hidden>{item.icon}</span>
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
            <div className="mt-3 border-t border-asphalt-100 px-2 pt-3">
              <p className="text-xs text-asphalt-500">Signed in as</p>
              <p className="mt-0.5 text-sm font-semibold text-asphalt-900">{user.name}</p>
              <p className="text-xs text-asphalt-500">{user.organisation ?? "Road authority"}</p>
            </div>
          </nav>
        </aside>
        <div className="min-w-0 flex-1">
          <nav className="mb-4 flex gap-2 overflow-x-auto lg:hidden">
            {NAV.map((item) => (
              <Link key={item.href} href={item.href} className="btn btn-ghost whitespace-nowrap">
                {item.icon} {item.label}
              </Link>
            ))}
          </nav>
          {children}
        </div>
      </div>
    </div>
  );
}
