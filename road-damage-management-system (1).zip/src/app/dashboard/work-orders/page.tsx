import Link from "next/link";
import { WorkOrderComposer } from "@/components/WorkOrderForms";
import { ProgressBar, SectionHeading, StatCard, WorkOrderBadge } from "@/components/ui";
import { WORK_ORDER_STATUS_LABEL, WORK_SCOPE_LABEL, type WorkScope } from "@/lib/constants";
import { formatDateTime, money, relativeTime } from "@/lib/format";
import { crewList, listReports, listWorkOrders } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function WorkOrdersPage({
  searchParams,
}: {
  searchParams: Promise<{ ref?: string; status?: string }>;
}) {
  const sp = await searchParams;
  const [orders, crews, reports] = await Promise.all([
    listWorkOrders({ status: sp.status, limit: 200 }),
    crewList(),
    listReports({ limit: 200 }),
  ]);

  const scheduled = orders.filter((o) => o.status === "scheduled").length;
  const active = orders.filter((o) => o.status === "in_progress").length;
  const completed = orders.filter((o) => o.status === "completed").length;
  const budget = orders.reduce((sum, o) => sum + Number(o.estimatedCost ?? 0), 0);
  const spend = orders.reduce((sum, o) => sum + Number(o.actualCost ?? 0), 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight">Maintenance work orders</h1>
        <p className="mt-1 text-sm text-asphalt-500">
          Schedule, assign and monitor repair jobs created from citizen complaints.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Scheduled" value={scheduled} hint="Awaiting crew start" icon="🗓️" />
        <StatCard label="Active jobs" value={active} hint="Crews on site" icon="🚧" />
        <StatCard label="Completed" value={completed} hint="Repairs finished" tone="text-emerald-600" icon="✅" />
        <StatCard
          label="Budget vs spend"
          value={`${money(budget)} / ${money(spend)}`}
          hint="Estimated cost vs actual cost"
          icon="💰"
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_1.5fr]">
        <WorkOrderComposer
          defaultReference={sp.ref ?? ""}
          crews={crews}
          reports={reports.map((r) => ({
            reference: r.reference,
            title: r.title,
            roadName: r.roadName,
            status: r.status,
          }))}
        />

        <div className="space-y-4">
          <SectionHeading
            title="All work orders"
            description={`${orders.length} job${orders.length === 1 ? "" : "s"} in the register`}
            action={
              <form action="/dashboard/work-orders" method="get" className="flex gap-2">
                <select name="status" defaultValue={sp.status ?? ""} className="field py-1.5 text-xs">
                  <option value="">All</option>
                  {Object.entries(WORK_ORDER_STATUS_LABEL).map(([value, label]) => (
                    <option key={value} value={value}>{label}</option>
                  ))}
                </select>
                <button type="submit" className="btn btn-ghost text-xs">Filter</button>
              </form>
            }
          />

          <div className="space-y-3">
            {orders.map((wo) => (
              <Link key={wo.id} href={`/dashboard/work-orders/${wo.id}`} className="card block p-4 hover:border-amber-300">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-mono text-xs font-bold text-asphalt-700">{wo.code}</span>
                  <WorkOrderBadge status={wo.status} />
                  <span className="ml-auto text-xs text-asphalt-500">{relativeTime(wo.createdAt)}</span>
                </div>
                <p className="mt-2 font-semibold text-asphalt-900">{wo.title}</p>
                <p className="text-sm text-asphalt-500">
                  {WORK_SCOPE_LABEL[wo.scope as WorkScope] ?? wo.scope} · crew {wo.crewName ?? "unassigned"} ·{" "}
                  <Link href={`/reports/${wo.reportReference}`} className="font-mono text-xs text-amber-700 hover:underline">
                    {wo.reportReference}
                  </Link>
                </p>
                <div className="mt-3">
                  <ProgressBar value={wo.progress} tone={wo.progress === 100 ? "bg-emerald-500" : "bg-amber-500"} />
                  <div className="mt-1 flex justify-between text-xs text-asphalt-500">
                    <span>{wo.progress}% complete</span>
                    <span>
                      {money(wo.estimatedCost)} est · {money(wo.actualCost)} actual
                    </span>
                  </div>
                </div>
                <p className="mt-2 text-xs text-asphalt-500">Scheduled {formatDateTime(wo.scheduledStart)}</p>
              </Link>
            ))}
            {orders.length === 0 && (
              <p className="card p-6 text-sm text-asphalt-500">
                No work orders yet. Dispatch a crew from the composer on the left.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
