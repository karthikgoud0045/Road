import Link from "next/link";
import { notFound } from "next/navigation";
import { WorkOrderProgressForm } from "@/components/WorkOrderForms";
import TileMap from "@/components/TileMap";
import { ProgressBar, SeverityBadge, StatusBadge, WorkOrderBadge } from "@/components/ui";
import { getCurrentUser } from "@/lib/auth";
import { DAMAGE_TYPE_LABEL, WORK_SCOPE_LABEL, type DamageType, type WorkScope } from "@/lib/constants";
import { coord, formatDateTime, money, relativeTime } from "@/lib/format";
import { getWorkOrder } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function WorkOrderDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const data = await getWorkOrder(Number(id));
  if (!data) notFound();
  const user = await getCurrentUser();

  const { order, report, log } = data;

  return (
    <div className="space-y-6">
      <div>
        <Link href="/dashboard/work-orders" className="text-sm font-semibold text-asphalt-500 hover:underline">
          ← Back to work orders
        </Link>
        <div className="mt-3 flex flex-wrap items-center gap-3">
          <h1 className="font-mono text-2xl font-extrabold tracking-tight">{order.code}</h1>
          <WorkOrderBadge status={order.status} />
          <span className="text-sm text-asphalt-500">{relativeTime(order.createdAt)}</span>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <div className="space-y-6">
          <div className="card p-5">
            <h2 className="text-lg font-bold">{order.title}</h2>
            <p className="mt-1 text-sm text-asphalt-500">
              {WORK_SCOPE_LABEL[order.scope as WorkScope] ?? order.scope} · crew{" "}
              <strong>{order.crewName ?? "unassigned"}</strong>
            </p>
            {order.description && (
              <p className="mt-3 text-sm leading-relaxed text-asphalt-700">{order.description}</p>
            )}
            <div className="mt-4">
              <div className="flex items-center justify-between text-sm">
                <span className="font-semibold text-asphalt-800">Repair progress</span>
                <span className="tabular-nums text-asphalt-500">{order.progress}%</span>
              </div>
              <div className="mt-2">
                <ProgressBar value={order.progress} tone={order.progress === 100 ? "bg-emerald-500" : "bg-amber-500"} />
              </div>
            </div>
            <dl className="mt-5 grid grid-cols-2 gap-4 border-t border-asphalt-100 pt-4 text-sm sm:grid-cols-3">
              <div>
                <dt className="text-xs uppercase tracking-wide text-asphalt-500">Scheduled start</dt>
                <dd className="font-medium">{formatDateTime(order.scheduledStart)}</dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-wide text-asphalt-500">Scheduled finish</dt>
                <dd className="font-medium">{formatDateTime(order.scheduledEnd)}</dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-wide text-asphalt-500">Started on site</dt>
                <dd className="font-medium">{formatDateTime(order.startedAt)}</dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-wide text-asphalt-500">Completed</dt>
                <dd className="font-medium">{formatDateTime(order.completedAt)}</dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-wide text-asphalt-500">Estimated cost</dt>
                <dd className="font-medium">{money(order.estimatedCost)}</dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-wide text-asphalt-500">Actual cost</dt>
                <dd className="font-medium">{money(order.actualCost)}</dd>
              </div>
              <div className="col-span-2 sm:col-span-3">
                <dt className="text-xs uppercase tracking-wide text-asphalt-500">Materials</dt>
                <dd className="font-medium">{order.materials ?? "—"}</dd>
              </div>
            </dl>
          </div>

          {(user?.role === "crew" || user?.role === "authority") && (
            <WorkOrderProgressForm id={order.id} status={order.status} progress={order.progress} showCost />
          )}

          <div className="card p-5">
            <h2 className="text-lg font-bold">Field log</h2>
            <ol className="mt-4 space-y-4">
              {log.map((entry) => (
                <li key={entry.id} className="relative pl-6">
                  <span className="absolute left-0 top-1.5 h-3 w-3 rounded-full bg-sky-500 ring-2 ring-white" />
                  <p className="text-sm text-asphalt-800">{entry.message}</p>
                  <p className="mt-0.5 text-xs text-asphalt-500">
                    {entry.authorName} · {entry.progress}% · {formatDateTime(entry.createdAt)}
                  </p>
                </li>
              ))}
              {log.length === 0 && <li className="text-sm text-asphalt-500">No field updates recorded yet.</li>}
            </ol>
          </div>
        </div>

        <div className="space-y-6">
          <div className="card p-5">
            <p className="text-xs font-bold uppercase tracking-wide text-asphalt-500">Linked complaint</p>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <Link href={`/reports/${report.reference}`} className="font-mono text-xs font-bold text-amber-700 hover:underline">
                {report.reference}
              </Link>
              <StatusBadge status={report.status} />
              <SeverityBadge severity={report.severity} />
            </div>
            <p className="mt-3 font-semibold text-asphalt-900">{report.title}</p>
            <p className="mt-1 text-sm text-asphalt-500">
              {DAMAGE_TYPE_LABEL[report.damageType as DamageType] ?? report.damageType} · {report.roadName}
            </p>
            <p className="mt-2 text-sm text-asphalt-700">{report.description}</p>
            <div className="mt-4">
              <TileMap
                height={200}
                zoom={15}
                center={{ lat: Number(report.latitude), lng: Number(report.longitude) }}
                markers={[
                  {
                    lat: Number(report.latitude),
                    lng: Number(report.longitude),
                    label: report.roadName,
                    tone: order.status === "completed" ? "emerald" : "amber",
                  },
                ]}
              />
              <p className="mt-2 font-mono text-xs text-asphalt-500">
                {coord(report.latitude)}, {coord(report.longitude)}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
