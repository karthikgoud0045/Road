import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import ReportForm from "@/components/ReportForm";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function ReportPage() {
  const user = await getCurrentUser();
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-10 sm:px-6">
        <div className="mb-8">
          <p className="text-xs font-bold uppercase tracking-[0.16em] text-amber-600">
            New complaint
          </p>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tight">Report road damage</h1>
          <p className="mt-2 max-w-2xl text-sm text-asphalt-500">
            Pin the exact location, describe the defect and submit. You will receive a reference code
            that lets you follow the complaint from verification through to repair.
          </p>
        </div>
        <ReportForm defaultName={user?.name ?? ""} defaultEmail={user?.email ?? ""} />
      </main>
      <SiteFooter />
    </div>
  );
}
