"use server";

import { redirect } from "next/navigation";
import { destroySession, getCurrentUser, roleHomePath } from "@/lib/auth";

export async function logoutAction() {
  await destroySession();
  redirect("/");
}

export async function goHomeAction() {
  const user = await getCurrentUser();
  redirect(user ? roleHomePath(user.role) : "/login");
}
