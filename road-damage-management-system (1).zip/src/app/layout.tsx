import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "RoadFix · Smart Road Damage Reporting & Maintenance Management",
  description:
    "A centralised platform for citizens to report potholes, cracks and damaged road surfaces, and for authorities to triage complaints, dispatch maintenance crews and track repair progress.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen text-asphalt-900 antialiased">{children}</body>
    </html>
  );
}
