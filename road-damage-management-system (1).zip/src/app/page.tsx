import Link from "next/link";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import { DamageChip, SeverityBadge, StatCard, StatusBadge } from "@/components/ui";
import { DAMAGE_TYPES, DAMAGE_TYPE_ICON, DAMAGE_TYPE_LABEL } from "@/lib/constants";
import { relativeTime } from "@/lib/format";
import { listReports, publicCounts } from "@/lib/queries";

export const dynamic = "force-dynamic";

const HERO_IMAGE =
  "https://images.pexels.com/photos/20518249/pexels-photo-20518249.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600";

const OBJECTIVES = [
  {
    icon: "📝",
    title: "Convenient reporting",
    body: "Citizens file a report in under two minutes — pin the exact spot on the map, add a photo and describe the damage.",
  },
  {
    icon: "🗂️",
    title: "Organised records",
    body: "Every complaint gets a unique reference and a permanent timeline, so nothing is lost in phone calls or paperwork.",
  },
  {
    icon: "⚖️",
    title: "Faster complaint review",
    body: "Authority staff verify, grade severity and reject duplicates from a single triage queue sorted by priority score.",
  },
  {
    icon: "🚧",
    title: "Crew coordination",
    body: "Verified damage becomes a work order with scope, schedule, budget and an assigned maintenance crew.",
  },
  {
    icon: "📈",
    title: "Progress monitoring",
    body: "Crews post progress updates; citizens and supervisors see live percentages and status changes.",
  },
  {
    icon: "🛡️",
    title: "Safer roads",
    body: "SLA ageing, critical backlog and zone hotspots highlight the repairs that reduce accident risk first.",
  },
];

const STEPS = [
  { n: "01", title: "Report", body: "Pin the location, choose the damage type and submit." },
  { n: "02", title: "Verify", body: "The road authority reviews, grades severity and confirms it." },
  { n: "03", title: "Dispatch", body: "A work order is created and assigned to a maintenance crew." },
  { n: "04", title: "Repair", body: "The crew logs progress until the repair is completed." },
  { n: "05", title: "Close", body: "Citizens confirm resolution and the record is archived." },
];

export default async function HomePage() {
  const [counts, latest] = await Promise.all([
    publicCounts(),
    listReports({ limit: 6 }),
  ]);

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />

      <main className="flex-1">
        {/* Hero */}
        <section className="relative overflow-hidden border-b border-asphalt-200 bg-asphalt-950">
          <div
            className="absolute inset-0 opacity-45"
            style={{
              backgroundImage: `url(${HERO_IMAGE})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
            }}
            aria-hidden
          />
          <div className="absolute inset-0 bg-gradient-to-r from-asphalt-950 via-asphalt-950/85 to-asphalt-900/40" aria-hidden />
          <div className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:py-24">
            <span className="inline-flex items-center gap-2 rounded-full bg-amber-400/15 px-3 py-1 text-xs font-semibold text-amber-300 ring-1 ring-inset ring-amber-400/30">
              🚧 Smart Road Damage Reporting & Maintenance Management System
            </span>
            <h1 className="mt-5 max-w-3xl text-4xl font-extrabold leading-tight tracking-tight text-white sm:text-5xl">
              Report road damage.
              <span className="block text-amber-400">Track the repair. Every step of the way.</span>
            </h1>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-asphalt-200">
              Potholes, cracks, edge breaks and water-logged roads make journeys slower and more
              dangerous. RoadFix replaces phone calls and paper complaints with one centralised
              platform that links citizen reports to authority triage and crew repair work orders.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/report" className="btn btn-accent px-5 py-2.5">
                Report road damage
              </Link>
              <Link
                href="/reports"
                className="btn border-white/25 bg-white/10 px-5 py-2.5 text-white hover:bg-white/20"
              >
                View live reports map
              </Link>
              <Link
                href="/track"
                className="btn border-white/25 bg-transparent px-5 py-2.5 text-white hover:bg-white/10"
              >
                Track my complaint
              </Link>
            </div>
            <dl className="mt-12 grid max-w-2xl grid-cols-3 gap-6 border-t border-white/10 pt-6">
              <div>
                <dt className="text-xs uppercase tracking-wide text-asphalt-400">Reports logged</dt>
                <dd className="text-3xl font-extrabold text-white">{counts.total}</dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-wide text-asphalt-400">Open cases</dt>
                <dd className="text-3xl font-extrabold text-amber-400">{counts.open}</dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-wide text-asphalt-400">Repaired</dt>
                <dd className="text-3xl font-extrabold text-emerald-400">{counts.resolved}</dd>
              </div>
            </dl>
          </div>
        </section>

        {/* Problem statement */}
        <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
          <div className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
            <div className="card p-6">
              <p className="text-xs font-bold uppercase tracking-[0.16em] text-amber-600">
                Problem statement
              </p>
              <h2 className="mt-2 text-2xl font-bold tracking-tight">
                Damaged roads cost commuters time and safety
              </h2>
              <ul className="mt-4 space-y-3 text-sm leading-relaxed text-asphalt-600">
                <li>
                  <strong className="text-asphalt-900">Reporting is hard.</strong> Damage is reported
                  by phone or in person, with no photo, no exact location and no record of who reported it.
                </li>
                <li>
                  <strong className="text-asphalt-900">Complaints get lost.</strong> Without a reference
                  number, citizens cannot follow up and authorities cannot prioritise objectively.
                </li>
                <li>
                  <strong className="text-asphalt-900">Maintenance is disconnected.</strong> Repair crews
                  receive verbal instructions, so scheduling, materials and completion status are invisible.
                </li>
                <li>
                  <strong className="text-asphalt-900">No progress visibility.</strong> Nobody can answer
                  the simple question: “when will this pothole be fixed?”
                </li>
              </ul>
            </div>
            <div className="card overflow-hidden">
              <img
                src="https://images.pexels.com/photos/11849379/pexels-photo-11849379.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=520&w=760"
                alt="Damaged road surface with a deep hole"
                className="h-48 w-full object-cover"
              />
              <div className="p-5">
                <h3 className="font-semibold text-asphalt-900">From complaint to closure</h3>
                <p className="mt-1 text-sm text-asphalt-500">
                  One record carries the report, the verification decision, the work order and every
                  progress update in a single audit trail.
                </p>
                <div className="mt-4 grid grid-cols-5 gap-1.5 text-center text-[11px] font-semibold text-asphalt-500">
                  {STEPS.map((s) => (
                    <div key={s.n} className="rounded-lg bg-asphalt-50 p-2">
                      <p className="text-asphalt-900">{s.n}</p>
                      <p className="mt-0.5">{s.title}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Objectives */}
        <section className="border-y border-asphalt-200 bg-white">
          <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-amber-600">
              Main objectives
            </p>
            <h2 className="mt-2 max-w-2xl text-2xl font-bold tracking-tight text-asphalt-900">
              A centralised link between reporting and maintenance management
            </h2>
            <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {OBJECTIVES.map((o) => (
                <div key={o.title} className="rounded-xl border border-asphalt-200 bg-asphalt-50/60 p-5">
                  <span className="text-2xl">{o.icon}</span>
                  <h3 className="mt-3 font-semibold text-asphalt-900">{o.title}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-asphalt-600">{o.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Damage types + latest */}
        <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
          <div className="grid gap-8 lg:grid-cols-[1fr_1.3fr]">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">What can you report?</h2>
              <p className="mt-2 text-sm text-asphalt-500">
                Any defect that affects the safety or usability of a road surface, shoulder or
                associated signage.
              </p>
              <div className="mt-6 grid grid-cols-2 gap-3">
                {DAMAGE_TYPES.map((t) => (
                  <Link
                    key={t}
                    href="/report"
                    className="card flex items-center gap-2 p-3 text-sm font-medium hover:border-amber-300"
                  >
                    <span className="text-lg">{DAMAGE_TYPE_ICON[t]}</span>
                    {DAMAGE_TYPE_LABEL[t]}
                  </Link>
                ))}
              </div>
            </div>
            <div>
              <div className="flex items-end justify-between">
                <h2 className="text-2xl font-bold tracking-tight">Latest public reports</h2>
                <Link href="/reports" className="text-sm font-semibold text-amber-700 hover:underline">
                  View all →
                </Link>
              </div>
              <div className="mt-6 space-y-3">
                {latest.length === 0 && (
                  <div className="card p-6 text-sm text-asphalt-500">
                    No reports yet — be the first to log a road defect in your area.
                  </div>
                )}
                {latest.map((r) => (
                  <Link
                    key={r.id}
                    href={`/reports/${r.reference}`}
                    className="card block p-4 transition hover:border-amber-300"
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      <DamageChip type={r.damageType} />
                      <SeverityBadge severity={r.severity} />
                      <StatusBadge status={r.status} />
                      <span className="ml-auto font-mono text-[11px] text-asphalt-400">{r.reference}</span>
                    </div>
                    <p className="mt-2 font-semibold text-asphalt-900">{r.title}</p>
                    <p className="mt-0.5 text-sm text-asphalt-500">
                      {r.roadName}
                      {r.zone ? ` · ${r.zone}` : ""} · reported {relativeTime(r.createdAt)}
                    </p>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Benefits CTA */}
        <section className="mx-auto max-w-7xl px-4 pb-4 sm:px-6">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label="Faster reporting" value="2 min" hint="Map pin + photo + description" icon="⚡" />
            <StatCard label="Traceable complaints" value="100%" hint="Every report has a reference" icon="🔖" />
            <StatCard label="Repair visibility" value="Live" hint="Progress logged by crews" icon="📡" />
            <StatCard label="Coordinated crews" value="1 desk" hint="Triage, dispatch and monitor" icon="🤝" />
          </div>
          <div className="card mt-6 flex flex-wrap items-center justify-between gap-4 bg-asphalt-900 p-6 text-white">
            <div>
              <h3 className="text-xl font-bold">Spotted a pothole on your street?</h3>
              <p className="mt-1 text-sm text-asphalt-300">
                Submit it now — you will get a reference code you can use to follow the repair.
              </p>
            </div>
            <div className="flex gap-3">
              <Link href="/report" className="btn btn-accent px-5 py-2.5">
                Start a report
              </Link>
              <Link href="/login" className="btn border-white/25 bg-white/10 px-5 py-2.5 text-white">
                Staff sign in
              </Link>
            </div>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
