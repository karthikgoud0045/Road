import { eq } from "drizzle-orm";
import { db } from "@/db";
import { reports, reportUpdates, workOrderUpdates, workOrders } from "@/db/schema";
import { requireRole } from "@/lib/auth";
import { isWorkOrderStatus } from "@/lib/constants";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

/** Crew + authority progress update on a work order. */
export async function PATCH(request: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const user = await requireRole(["crew", "authority"]);
  if (!user) return Response.json({ error: "Not permitted" }, { status: 403 });

  const orderId = Number(id);
  if (!Number.isFinite(orderId)) return Response.json({ error: "Invalid work order" }, { status: 400 });

  const rows = await db.select().from(workOrders).where(eq(workOrders.id, orderId)).limit(1);
  const order = rows[0];
  if (!order) return Response.json({ error: "Work order not found" }, { status: 404 });

  if (user.role === "crew" && order.crewId !== user.id) {
    return Response.json({ error: "This work order is assigned to another crew" }, { status: 403 });
  }

  const body = (await request.json().catch(() => ({}))) as {
    status?: string;
    progress?: number;
    message?: string;
    actualCost?: string;
  };

  const nextStatus = body.status && isWorkOrderStatus(body.status) ? body.status : null;
  const rawProgress = Number(body.progress);
  const nextProgress = Number.isFinite(rawProgress) ? Math.max(0, Math.min(100, Math.round(rawProgress))) : null;
  const message = String(body.message ?? "").trim();
  const actualCost = String(body.actualCost ?? "").trim();

  if (!nextStatus && nextProgress === null && !message && !actualCost) {
    return Response.json({ error: "Nothing to update" }, { status: 400 });
  }

  const now = new Date();
  const startedAt =
    nextStatus === "in_progress" && !order.startedAt ? now : order.startedAt;
  const completedAt = nextStatus === "completed" ? now : order.completedAt;
  const progress =
    nextStatus === "completed" ? 100 : nextProgress ?? order.progress;

  await db
    .update(workOrders)
    .set({
      status: nextStatus ?? order.status,
      progress,
      startedAt,
      completedAt,
      actualCost: actualCost || order.actualCost,
      updatedAt: now,
    })
    .where(eq(workOrders.id, order.id));

  await db.insert(workOrderUpdates).values({
    workOrderId: order.id,
    authorName: user.name,
    message:
      message ||
      (nextStatus ? `Status changed to ${WORK_STATUS_LABEL(nextStatus)}.` : `Progress updated to ${progress}%.`),
    progress,
    statusFrom: order.status,
    statusTo: nextStatus,
  });

  // Keep the parent report in sync.
  const reportRows = await db.select().from(reports).where(eq(reports.id, order.reportId)).limit(1);
  const report = reportRows[0];
  if (report) {
    let reportStatus = report.status;
    if (nextStatus === "in_progress") reportStatus = "in_progress";
    if (nextStatus === "paused") reportStatus = "on_hold";
    if (nextStatus === "cancelled") reportStatus = "on_hold";
    if (nextStatus === "completed") reportStatus = "resolved";

    await db
      .update(reports)
      .set({
        status: reportStatus,
        resolvedAt: nextStatus === "completed" ? now : report.resolvedAt,
        updatedAt: now,
      })
      .where(eq(reports.id, report.id));

    await db.insert(reportUpdates).values({
      reportId: report.id,
      authorId: user.id,
      authorName: user.name,
      authorRole: user.role,
      message:
        nextStatus === "completed"
          ? `Repair completed by ${user.name}. Reported damage has been fixed.`
          : message || `Maintenance update: work order ${order.code} is ${nextStatus ?? "at"} ${progress}%.`,
      statusFrom: report.status,
      statusTo: reportStatus,
    });
  }

  return Response.json({ ok: true });
}

function WORK_STATUS_LABEL(status: string) {
  const map: Record<string, string> = {
    scheduled: "Scheduled",
    in_progress: "In progress",
    paused: "Paused",
    completed: "Completed",
    cancelled: "Cancelled",
  };
  return map[status] ?? status;
}
