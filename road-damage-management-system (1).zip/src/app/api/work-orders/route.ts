import { eq } from "drizzle-orm";
import { db } from "@/db";
import { reports, reportUpdates, users, workOrderUpdates, workOrders } from "@/db/schema";
import { requireRole } from "@/lib/auth";
import { WORK_SCOPE_LABEL, WORK_ORDER_STATUS_LABEL, type WorkScope } from "@/lib/constants";
import { nextReference } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const user = await requireRole(["authority"]);
  if (!user) return Response.json({ error: "Only road authority staff can create work orders" }, { status: 403 });

  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const reference = String(body.reference ?? "");
  if (!reference) return Response.json({ error: "A report reference is required" }, { status: 400 });

  const found = await db.select().from(reports).where(eq(reports.reference, reference)).limit(1);
  const report = found[0];
  if (!report) return Response.json({ error: "Report not found" }, { status: 404 });

  const crewId = Number(body.crewId) || null;
  let crewName: string | null = null;
  if (crewId) {
    const crewRows = await db.select({ name: users.name }).from(users).where(eq(users.id, crewId)).limit(1);
    crewName = crewRows[0]?.name ?? null;
    if (!crewName) return Response.json({ error: "Selected crew not found" }, { status: 400 });
  }

  const scope = String(body.scope ?? "patch_repair") as WorkScope;
  const code = await nextReference("WO-", "work_orders");
  const scheduledStart = body.scheduledStart ? new Date(String(body.scheduledStart)) : null;
  const scheduledEnd = body.scheduledEnd ? new Date(String(body.scheduledEnd)) : null;
  const estimatedCost = String(body.estimatedCost ?? "").trim();

  const inserted = await db
    .insert(workOrders)
    .values({
      code,
      reportId: report.id,
      title: String(body.title ?? report.title).trim() || report.title,
      scope: scope in WORK_SCOPE_LABEL ? scope : "patch_repair",
      description: String(body.description ?? "").trim() || null,
      status: "scheduled",
      priority: String(body.priority ?? report.severity),
      progress: 0,
      crewId,
      crewName,
      scheduledStart,
      scheduledEnd,
      estimatedCost: estimatedCost || null,
      materials: String(body.materials ?? "").trim() || null,
    })
    .returning();

  await db
    .update(reports)
    .set({
      status: "assigned",
      assignedCrewId: crewId,
      severity: ["low", "medium", "high", "critical"].includes(String(body.priority))
        ? String(body.priority)
        : report.severity,
      updatedAt: new Date(),
    })
    .where(eq(reports.id, report.id));

  await db.insert(reportUpdates).values({
    reportId: report.id,
    authorId: user.id,
    authorName: user.name,
    authorRole: "authority",
    message: `Work order ${code} created (${WORK_SCOPE_LABEL[scope]})${
      crewName ? ` and assigned to ${crewName}` : ""
    }.`,
    statusFrom: report.status,
    statusTo: "assigned",
  });

  if (crewName) {
    await db.insert(workOrderUpdates).values({
      workOrderId: inserted[0].id,
      authorName: user.name,
      message: `Work order scheduled and assigned to ${crewName}.`,
      progress: 0,
      statusTo: WORK_ORDER_STATUS_LABEL.scheduled,
    });
  }

  return Response.json({ ok: true, code });
}
