import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, hashPassword, roleHomePath, verifyPassword } from "@/lib/auth";
import { isRole } from "@/lib/constants";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: { mode?: string; email?: string; password?: string; name?: string; role?: string; phone?: string; organisation?: string };
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Invalid request body" }, { status: 400 });
  }

  const email = (body.email ?? "").trim().toLowerCase();
  const password = body.password ?? "";

  if (!email || !password) {
    return Response.json({ error: "Email and password are required" }, { status: 400 });
  }

  if (body.mode === "register") {
    const name = (body.name ?? "").trim();
    if (name.length < 2) return Response.json({ error: "Please enter your name" }, { status: 400 });
    if (password.length < 6) {
      return Response.json({ error: "Password must be at least 6 characters" }, { status: 400 });
    }
    const role = body.role && isRole(body.role) ? body.role : "citizen";
    const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing.length > 0) {
      return Response.json({ error: "An account with this email already exists" }, { status: 409 });
    }
    const inserted = await db
      .insert(users)
      .values({
        name,
        email,
        passwordHash: hashPassword(password),
        role,
        phone: body.phone?.trim() || null,
        organisation: body.organisation?.trim() || null,
      })
      .returning({ id: users.id, role: users.role });
    const user = inserted[0];
    await createSession(user.id);
    return Response.json({ ok: true, role: user.role, redirectTo: roleHomePath(user.role) });
  }

  const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
  const user = rows[0];
  if (!user || !verifyPassword(password, user.passwordHash)) {
    return Response.json({ error: "Incorrect email or password" }, { status: 401 });
  }
  await createSession(user.id);
  return Response.json({ ok: true, role: user.role, redirectTo: roleHomePath(user.role) });
}
