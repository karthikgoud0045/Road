import { eq } from "drizzle-orm";
import { db } from "@/db";
import { reports, reportUpdates } from "@/db/schema";
import { getCurrentUser, requireRole } from "@/lib/auth";
import { isReportStatus, isSeverity, REPORT_STATUS_LABEL } from "@/lib/constants";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ reference: string }> };

async function loadReport(reference: string) {
  const rows = await db.select().from(reports).where(eq(reports.reference, reference)).limit(1);
  return rows[0] ?? null;
}

/** Public / internal comment on a report. */
export async function POST(request: Request, ctx: Ctx) {
  const { reference } = await ctx.params;
  const body = (await request.json().catch(() => ({}))) as {
    message?: string;
    isPublic?: boolean;
  };
  const message = String(body.message ?? "").trim();
  if (message.length < 2) return Response.json({ error: "Please write a message" }, { status: 400 });

  const report = await loadReport(reference);
  if (!report) return Response.json({ error: "Report not found" }, { status: 404 });

  const user = await getCurrentUser();
  if (!user) return Response.json({ error: "Please sign in to comment" }, { status: 401 });

  const isPublic = body.isPublic !== false;
  await db.insert(reportUpdates).values({
    reportId: report.id,
    authorId: user.id,
    authorName: user.name,
    authorRole: user.role,
    message,
    isPublic,
  });
  await db.update(reports).set({ updatedAt: new Date() }).where(eq(reports.id, report.id));

  return Response.json({ ok: true });
}

/** Authority triage decision: status, severity, internal note. */
export async function PATCH(request: Request, ctx: Ctx) {
  const { reference } = await ctx.params;
  const user = await requireRole(["authority"]);
  if (!user) return Response.json({ error: "Only road authority staff can triage reports" }, { status: 403 });

  const body = (await request.json().catch(() => ({}))) as {
    status?: string;
    severity?: string;
    message?: string;
    isPublic?: boolean;
  };

  const report = await loadReport(reference);
  if (!report) return Response.json({ error: "Report not found" }, { status: 404 });

  const nextStatus = body.status && isReportStatus(body.status) ? body.status : null;
  const nextSeverity = body.severity && isSeverity(body.severity) ? body.severity : null;
  const message = String(body.message ?? "").trim();

  if (!nextStatus && !nextSeverity && !message) {
    return Response.json({ error: "Nothing to update" }, { status: 400 });
  }

  const now = new Date();
  const changes: string[] = [];
  if (nextStatus && nextStatus !== report.status) {
    changes.push(`status → ${REPORT_STATUS_LABEL[nextStatus]}`);
  }
  if (nextSeverity && nextSeverity !== report.severity) {
    changes.push(`severity → ${nextSeverity}`);
  }

  await db
    .update(reports)
    .set({
      status: nextStatus ?? report.status,
      severity: nextSeverity ?? report.severity,
      verifiedById: nextStatus === "verified" || nextStatus === "rejected" ? user.id : report.verifiedById,
      resolvedAt:
        nextStatus === "resolved" || nextStatus === "closed" ? now : report.resolvedAt,
      updatedAt: now,
    })
    .where(eq(reports.id, report.id));

  await db.insert(reportUpdates).values({
    reportId: report.id,
    authorId: user.id,
    authorName: user.name,
    authorRole: "authority",
    message:
      message ||
      `${changes.join(", ")} recorded by ${user.name}${
        nextStatus === "rejected" ? ". Not accepted for maintenance." : "."
      }`,
    statusFrom: nextStatus ? report.status : null,
    statusTo: nextStatus,
    isPublic: body.isPublic !== false,
  });

  return Response.json({ ok: true });
}
