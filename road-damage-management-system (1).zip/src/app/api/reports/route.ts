import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { reports, reportUpdates } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { isDamageType, isSeverity } from "@/lib/constants";
import { listReports, nextReference } from "@/lib/queries";

export const dynamic = "force-dynamic";

/** Great-circle distance in metres between two lat/lng pairs. */
function distanceMetres(aLat: number, aLng: number, bLat: number, bLng: number) {
  const R = 6371000;
  const dLat = ((bLat - aLat) * Math.PI) / 180;
  const dLng = ((bLng - aLng) * Math.PI) / 180;
  const lat1 = (aLat * Math.PI) / 180;
  const lat2 = (bLat * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
  return 2 * R * Math.asin(Math.sqrt(h));
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const rows = await listReports({
    q: url.searchParams.get("q") ?? undefined,
    status: url.searchParams.get("status") ?? undefined,
    damageType: url.searchParams.get("damageType") ?? undefined,
    severity: url.searchParams.get("severity") ?? undefined,
    zone: url.searchParams.get("zone") ?? undefined,
    limit: Number(url.searchParams.get("limit") ?? 300),
  });
  return Response.json({ reports: rows });
}

export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Invalid request body" }, { status: 400 });
  }

  const title = String(body.title ?? "").trim();
  const description = String(body.description ?? "").trim();
  const roadName = String(body.roadName ?? "").trim();
  const reporterName = String(body.reporterName ?? "").trim();
  const latitude = Number(body.latitude);
  const longitude = Number(body.longitude);

  if (title.length < 4) return Response.json({ error: "Please give the report a short title" }, { status: 400 });
  if (description.length < 10) return Response.json({ error: "Please describe the damage" }, { status: 400 });
  if (!roadName) return Response.json({ error: "Road / street name is required" }, { status: 400 });
  if (!reporterName) return Response.json({ error: "Reporter name is required" }, { status: 400 });
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
    return Response.json({ error: "Pin the damage location on the map" }, { status: 400 });
  }

  const damageType = isDamageType(String(body.damageType ?? "")) ? String(body.damageType) : "other";
  const severity = isSeverity(String(body.severity ?? "")) ? String(body.severity) : "medium";
  const photoUrl = String(body.photoUrl ?? "").trim() || null;

  const user = await getCurrentUser();

  // Duplicate detection: same road within 120 m that is still open.
  const nearby = await listReports({ q: roadName.split(" ")[0] ?? roadName, limit: 60 });
  const duplicate = nearby.find(
    (r) =>
      !["resolved", "closed", "rejected"].includes(r.status) &&
      distanceMetres(latitude, longitude, Number(r.latitude), Number(r.longitude)) < 120,
  );

  const reference = await nextReference("RD-", "reports");

  const inserted = await db
    .insert(reports)
    .values({
      reference,
      title,
      description,
      damageType,
      severity,
      status: "submitted",
      roadName,
      landmark: String(body.landmark ?? "").trim() || null,
      zone: String(body.zone ?? "").trim() || null,
      latitude: latitude.toFixed(6),
      longitude: longitude.toFixed(6),
      reporterName,
      reporterEmail: String(body.reporterEmail ?? "").trim() || user?.email || null,
      reporterPhone: String(body.reporterPhone ?? "").trim() || null,
      reporterId: user?.id ?? null,
      photoUrl,
    })
    .returning();

  const report = inserted[0];

  await db.insert(reportUpdates).values({
    reportId: report.id,
    authorName: reporterName,
    authorRole: user ? user.role : "citizen",
    message: duplicate
      ? `Report submitted and linked to an existing open case nearby (${duplicate.reference}).`
      : "Report submitted and queued for road authority verification.",
    statusTo: "submitted",
  });

  if (duplicate) {
    await db
      .update(reports)
      .set({ supports: sql`${reports.supports} + 1`, updatedAt: new Date() })
      .where(eq(reports.id, duplicate.id));
  }

  return Response.json({ ok: true, report: { reference: report.reference, title: report.title, duplicateOf: duplicate?.reference ?? null } }, { status: 201 });
}

/** Support / "me too" endpoint used by report detail page. */
export async function PUT(request: Request) {
  let body: { reference?: string };
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Invalid request body" }, { status: 400 });
  }
  const reference = String(body.reference ?? "");
  if (!reference) return Response.json({ error: "reference is required" }, { status: 400 });

  const rows = await db
    .update(reports)
    .set({ supports: sql`${reports.supports} + 1`, updatedAt: new Date() })
    .where(and(eq(reports.reference, reference)))
    .returning({ supports: reports.supports });

  if (rows.length === 0) return Response.json({ error: "Report not found" }, { status: 404 });
  return Response.json({ ok: true, supports: rows[0].supports });
}
