import {
  boolean,
  index,
  integer,
  numeric,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/** Roles: citizen (public reporter), authority (municipal reviewer), crew (maintenance team). */
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    email: text("email").notNull(),
    passwordHash: text("password_hash").notNull(),
    role: text("role").notNull().default("citizen"),
    organisation: text("organisation"),
    phone: text("phone"),
    zone: text("zone"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("users_email_unique").on(table.email)],
);

export const sessions = pgTable(
  "sessions",
  {
    id: serial("id").primaryKey(),
    token: text("token").notNull(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  },
  (table) => [uniqueIndex("sessions_token_unique").on(table.token)],
);

/** A citizen / authority submitted road damage report. */
export const reports = pgTable(
  "reports",
  {
    id: serial("id").primaryKey(),
    reference: text("reference").notNull(),
    title: text("title").notNull(),
    description: text("description").notNull(),
    damageType: text("damage_type").notNull().default("pothole"),
    severity: text("severity").notNull().default("medium"),
    /** submitted | verified | rejected | assigned | in_progress | on_hold | resolved | closed */
    status: text("status").notNull().default("submitted"),
    roadName: text("road_name").notNull(),
    landmark: text("landmark"),
    zone: text("zone"),
    latitude: numeric("latitude", { precision: 10, scale: 6 }).notNull(),
    longitude: numeric("longitude", { precision: 10, scale: 6 }).notNull(),
    reporterName: text("reporter_name").notNull(),
    reporterEmail: text("reporter_email"),
    reporterPhone: text("reporter_phone"),
    reporterId: integer("reporter_id").references(() => users.id, { onDelete: "set null" }),
    verifiedById: integer("verified_by_id").references(() => users.id, { onDelete: "set null" }),
    assignedCrewId: integer("assigned_crew_id").references(() => users.id, {
      onDelete: "set null",
    }),
    photoUrl: text("photo_url"),
    supports: integer("supports").notNull().default(0),
    duplicateOf: integer("duplicate_of"),
    resolvedAt: timestamp("resolved_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("reports_reference_unique").on(table.reference),
    index("reports_status_idx").on(table.status),
    index("reports_created_idx").on(table.createdAt),
  ],
);

/** Public + internal timeline entries on a report. */
export const reportUpdates = pgTable(
  "report_updates",
  {
    id: serial("id").primaryKey(),
    reportId: integer("report_id")
      .notNull()
      .references(() => reports.id, { onDelete: "cascade" }),
    authorId: integer("author_id").references(() => users.id, { onDelete: "set null" }),
    authorName: text("author_name").notNull(),
    authorRole: text("author_role").notNull().default("system"),
    message: text("message").notNull(),
    statusFrom: text("status_from"),
    statusTo: text("status_to"),
    isPublic: boolean("is_public").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("report_updates_report_idx").on(table.reportId)],
);

/** Maintenance job created from a verified report. */
export const workOrders = pgTable(
  "work_orders",
  {
    id: serial("id").primaryKey(),
    code: text("code").notNull(),
    reportId: integer("report_id")
      .notNull()
      .references(() => reports.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    scope: text("scope").notNull().default("patch_repair"),
    description: text("description"),
    /** scheduled | in_progress | paused | completed | cancelled */
    status: text("status").notNull().default("scheduled"),
    priority: text("priority").notNull().default("medium"),
    progress: integer("progress").notNull().default(0),
    crewId: integer("crew_id").references(() => users.id, { onDelete: "set null" }),
    crewName: text("crew_name"),
    scheduledStart: timestamp("scheduled_start", { withTimezone: true }),
    scheduledEnd: timestamp("scheduled_end", { withTimezone: true }),
    startedAt: timestamp("started_at", { withTimezone: true }),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    estimatedCost: numeric("estimated_cost", { precision: 12, scale: 2 }),
    actualCost: numeric("actual_cost", { precision: 12, scale: 2 }),
    materials: text("materials"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("work_orders_code_unique").on(table.code),
    index("work_orders_status_idx").on(table.status),
  ],
);

/** Progress log for a work order. */
export const workOrderUpdates = pgTable(
  "work_order_updates",
  {
    id: serial("id").primaryKey(),
    workOrderId: integer("work_order_id")
      .notNull()
      .references(() => workOrders.id, { onDelete: "cascade" }),
    authorName: text("author_name").notNull(),
    message: text("message").notNull(),
    progress: integer("progress").notNull().default(0),
    statusFrom: text("status_from"),
    statusTo: text("status_to"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("work_order_updates_wo_idx").on(table.workOrderId)],
);

export type User = typeof users.$inferSelect;
export type Report = typeof reports.$inferSelect;
export type ReportUpdate = typeof reportUpdates.$inferSelect;
export type WorkOrder = typeof workOrders.$inferSelect;
export type WorkOrderUpdate = typeof workOrderUpdates.$inferSelect;
