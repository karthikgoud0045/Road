import { randomBytes, scryptSync } from "node:crypto";
import { readFileSync } from "node:fs";
import { Client } from "pg";

function loadEnv() {
  try {
    const raw = readFileSync(new URL("../.env", import.meta.url), "utf8");
    for (const line of raw.split("\n")) {
      const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/i);
      if (match && !process.env[match[1]]) process.env[match[1]] = match[2];
    }
  } catch {
    // ignore
  }
}

function hashPassword(password) {
  const salt = randomBytes(16).toString("hex");
  const derived = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${derived}`;
}

const PASSWORD = "demo1234";
const BASE = { lat: 6.4531, lng: 3.3958 };
const day = 86400000;
const ago = (d) => new Date(Date.now() - d * day);

function offset(i) {
  return {
    lat: BASE.lat + ((i % 6) - 2.5) * 0.011,
    lng: BASE.lng + (Math.floor(i / 6) - 1.5) * 0.013,
  };
}

const USERS = [
  { name: "Amara Okafor", email: "authority@roadfix.gov", role: "authority", organisation: "City Roads Authority", zone: null, phone: "+1 555 0100" },
  { name: "Musa Diallo", email: "crew@roadfix.gov", role: "crew", organisation: "RapidFix Crew A", zone: "Zone 1 · Central", phone: "+1 555 0111" },
  { name: "Priya Sharma", email: "crew2@roadfix.gov", role: "crew", organisation: "RapidFix Crew B", zone: "Zone 3 · South", phone: "+1 555 0112" },
  { name: "Tunde Bello", email: "citizen@roadfix.gov", role: "citizen", organisation: null, zone: null, phone: "+1 555 0122" },
];

const REPORTS = [
  {
    title: "Deep pothole in the left lane",
    damageType: "pothole", severity: "critical", status: "in_progress",
    roadName: "Independence Avenue", landmark: "opposite City Mall gate 2", zone: "Zone 1 · Central",
    description: "Large pothole roughly 60 cm wide and 20 cm deep. Vehicles swerve into the adjacent lane to avoid it and it floods after rain.",
    supports: 27, daysAgo: 12, crew: 1, workOrder: { status: "in_progress", progress: 60, scope: "patch_repair", est: 1800, act: 1450, start: 3 },
  },
  {
    title: "Longitudinal crack across the carriageway",
    damageType: "crack", severity: "medium", status: "verified",
    roadName: "Unity Boulevard", landmark: "between 3rd and 4th junction", zone: "Zone 2 · North",
    description: "A 15 m long crack that is widening and letting water into the base layer. Needs sealing before the rainy season.",
    supports: 11, daysAgo: 6, crew: null, workOrder: null,
  },
  {
    title: "Broken edge on the bridge approach",
    damageType: "edge_break", severity: "high", status: "assigned",
    roadName: "Riverside Drive", landmark: "north approach of the old bridge", zone: "Zone 4 · East",
    description: "The asphalt edge has collapsed leaving a 30 cm drop next to the footpath. Dangerous for cyclists and motorbikes at night.",
    supports: 19, daysAgo: 9, crew: 2, workOrder: { status: "scheduled", progress: 0, scope: "edge_repair", est: 2400, act: null, start: null },
  },
  {
    title: "Standing water after every rainfall",
    damageType: "flooding", severity: "high", status: "submitted",
    roadName: "Market Street", landmark: "in front of the central market", zone: "Zone 1 · Central",
    description: "The blocked drain leaves a 20 m stretch flooded for days. Pedestrians and traders cannot pass and stagnant water is a health risk.",
    supports: 34, daysAgo: 3, crew: null, workOrder: null,
  },
  {
    title: "Faded lane markings at the junction",
    damageType: "sign_damage", severity: "low", status: "verified",
    roadName: "Crescent Road", landmark: "Hill Park junction", zone: "Zone 5 · West",
    description: "Lane markings and the stop line are almost invisible, causing confusion and near misses at peak hours.",
    supports: 8, daysAgo: 15, crew: null, workOrder: null,
  },
  {
    title: "Pothole cluster near the school gate",
    damageType: "pothole", severity: "critical", status: "resolved",
    roadName: "Palm Grove Lane", landmark: "St. Agnes primary school gate", zone: "Zone 3 · South",
    description: "Three linked potholes right where children cross. Very risky during morning drop-off.",
    supports: 41, daysAgo: 26, crew: 1, workOrder: { status: "completed", progress: 100, scope: "patch_repair", est: 1500, act: 1620, start: 22 },
  },
  {
    title: "Surface wear and loose gravel",
    damageType: "surface_wear", severity: "medium", status: "in_progress",
    roadName: "Industrial Estate Road", landmark: "near the freight depot", zone: "Zone 4 · East",
    description: "Heavy trucks have stripped the surface layer. Loose stones are cracking windscreens and the road is slippery when wet.",
    supports: 15, daysAgo: 20, crew: 2, workOrder: { status: "in_progress", progress: 35, scope: "resurfacing", est: 9800, act: 4100, start: 4 },
  },
  {
    title: "Fallen debris blocking one lane",
    damageType: "debris", severity: "medium", status: "resolved",
    roadName: "Airport Link Road", landmark: "under the flyover", zone: "Zone 2 · North",
    description: "Construction rubble dumped on the carriageway reduced the road to a single lane during rush hour.",
    supports: 22, daysAgo: 32, crew: 1, workOrder: { status: "completed", progress: 100, scope: "clearing", est: 400, act: 380, start: 30 },
  },
  {
    title: "Alligator cracking on the bus lane",
    damageType: "crack", severity: "medium", status: "assigned",
    roadName: "Central Station Road", landmark: "bus bay B", zone: "Zone 1 · Central",
    description: "Interlocking cracks across the bus lane are starting to break out and form potholes.",
    supports: 13, daysAgo: 8, crew: 1, workOrder: { status: "scheduled", progress: 0, scope: "crack_sealing", est: 1100, act: null, start: null },
  },
  {
    title: "Sunken manhole cover in the cycle lane",
    damageType: "other", severity: "high", status: "submitted",
    roadName: "Greenway Avenue", landmark: "cycle lane by the park", zone: "Zone 5 · West",
    description: "The manhole cover sits 8 cm below the surface. Cyclists cannot avoid it without swerving into traffic.",
    supports: 25, daysAgo: 4, crew: null, workOrder: null,
  },
  {
    title: "Pothole at the taxi rank entrance",
    damageType: "pothole", severity: "medium", status: "submitted",
    roadName: "Old Town Road", landmark: "taxi rank entrance", zone: "Zone 3 · South",
    description: "Pothole about 40 cm across at the entrance to the rank. Buses drop into it and damage the wheel alignment.",
    supports: 9, daysAgo: 2, crew: null, workOrder: null,
  },
  {
    title: "Damaged guardrail after a collision",
    damageType: "sign_damage", severity: "high", status: "on_hold",
    roadName: "Hillcrest Road", landmark: "bend before the water tower", zone: "Zone 5 · West",
    description: "Three sections of guardrail are bent into the carriageway with exposed metal edges. Awaiting materials for the replacement.",
    supports: 18, daysAgo: 14, crew: 2, workOrder: { status: "paused", progress: 20, scope: "signage", est: 3200, act: 600, start: 10 },
  },
];

const NOTE_BY_STATUS = {
  submitted: "Report submitted and queued for road authority verification.",
  verified: "Complaint verified from citizen photos and a field inspection. Severity graded and added to the repair programme.",
  assigned: "Work order created and assigned to the maintenance crew.",
  in_progress: "Crew is on site and repair work has started.",
  on_hold: "Work paused pending materials and budget approval.",
  resolved: "Repair completed and inspected. The road surface is back in service.",
  rejected: "Reviewed and not accepted for maintenance — the defect falls under the utility company's remit.",
  closed: "Case closed after post-repair inspection.",
};

async function main() {
  loadEnv();
  const client = new Client({ connectionString: process.env.DATABASE_URL });
  await client.connect();

  const existing = await client.query("select count(*)::int as n from reports");
  if (existing.rows[0].n > 0) {
    console.log(`Seed skipped — ${existing.rows[0].n} reports already present.`);
    await client.end();
    return;
  }

  const userIds = {};
  for (const u of USERS) {
    const res = await client.query(
      `insert into users (name, email, password_hash, role, organisation, phone, zone)
       values ($1,$2,$3,$4,$5,$6,$7)
       on conflict (email) do update set name = excluded.name
       returning id`,
      [u.name, u.email, hashPassword(PASSWORD), u.role, u.organisation, u.phone, u.zone],
    );
    userIds[u.email] = res.rows[0].id;
  }
  const crewUsers = USERS.filter((u) => u.role === "crew");
  const year = new Date().getFullYear();

  let reportIndex = 0;
  let workIndex = 0;

  for (const r of REPORTS) {
    reportIndex += 1;
    const reference = `RD-${year}-${String(reportIndex).padStart(4, "0")}`;
    const pos = offset(reportIndex);
    const createdAt = ago(r.daysAgo);
    const resolvedAt = ["resolved", "closed"].includes(r.status)
      ? ago(Math.max(0, r.daysAgo - 6))
      : null;
    const crewUserId = r.crew ? userIds[crewUsers[r.crew - 1].email] : null;
    const crewName = r.crew ? crewUsers[r.crew - 1].name : null;

    const reportRes = await client.query(
      `insert into reports
        (reference, title, description, damage_type, severity, status, road_name, landmark, zone,
         latitude, longitude, reporter_name, reporter_email, reporter_phone, reporter_id,
         verified_by_id, assigned_crew_id, supports, resolved_at, created_at, updated_at)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$20)
       returning id`,
      [
        reference,
        r.title,
        r.description,
        r.damageType,
        r.severity,
        r.status,
        r.roadName,
        r.landmark,
        r.zone,
        pos.lat.toFixed(6),
        pos.lng.toFixed(6),
        r.crew ? USERS[0].name : USERS[3].name,
        USERS[3].email,
        USERS[3].phone,
        userIds[USERS[3].email],
        ["submitted"].includes(r.status) ? null : userIds[USERS[0].email],
        crewUserId,
        r.supports,
        resolvedAt,
        createdAt,
      ],
    );
    const reportId = reportRes.rows[0].id;

    // Timeline: submission → verified → assigned → progress → resolved
    const flow = [];
    flow.push({ status: "submitted", author: USERS[3].name, role: "citizen", at: createdAt, note: NOTE_BY_STATUS.submitted });
    if (r.status !== "submitted") {
      flow.push({ status: "verified", author: USERS[0].name, role: "authority", at: ago(Math.max(0, r.daysAgo - 1)), note: NOTE_BY_STATUS.verified });
    }
    if (r.workOrder) {
      flow.push({ status: "assigned", author: USERS[0].name, role: "authority", at: ago(Math.max(0, r.daysAgo - 2)), note: NOTE_BY_STATUS.assigned });
      if (r.status === "in_progress") {
        flow.push({ status: "in_progress", author: crewName ?? USERS[0].name, role: "crew", at: ago(Math.max(1, r.daysAgo - 4)), note: NOTE_BY_STATUS.in_progress });
      }
      if (r.status === "on_hold") {
        flow.push({ status: "on_hold", author: USERS[0].name, role: "authority", at: ago(Math.max(1, r.daysAgo - 5)), note: NOTE_BY_STATUS.on_hold });
      }
    }
    if (["resolved", "closed"].includes(r.status)) {
      flow.push({ status: "resolved", author: crewName ?? USERS[0].name, role: "crew", at: resolvedAt, note: NOTE_BY_STATUS.resolved });
      if (r.status === "closed") {
        flow.push({ status: "closed", author: USERS[0].name, role: "authority", at: ago(Math.max(0, r.daysAgo - 8)), note: NOTE_BY_STATUS.closed });
      }
    }

    for (const step of flow) {
      await client.query(
        `insert into report_updates (report_id, author_id, author_name, author_role, message, status_from, status_to, is_public, created_at)
         values ($1,$2,$3,$4,$5,null,$6,true,$7)`,
        [reportId, step.role === "citizen" ? userIds[USERS[3].email] : userIds[USERS[0].email], step.author, step.role, step.note, step.status, step.at],
      );
    }

    // A couple of public comments from citizens
    if (reportIndex % 3 === 0) {
      await client.query(
        `insert into report_updates (report_id, author_id, author_name, author_role, message, is_public, created_at)
         values ($1,$2,$3,$4,$5,true,$6)`,
        [reportId, userIds[USERS[3].email], USERS[3].name, "citizen", "Confirmed still getting worse this week — please prioritise.", ago(Math.max(1, r.daysAgo - 3))],
      );
    }

    if (r.workOrder) {
      workIndex += 1;
      const code = `WO-${year}-${String(workIndex).padStart(4, "0")}`;
      const scheduledStart = r.workOrder.start ? ago(r.workOrder.start) : ago(-3);
      const scheduledEnd = new Date(new Date(scheduledStart).getTime() + 2 * day);
      const woRes = await client.query(
        `insert into work_orders
          (code, report_id, title, scope, description, status, priority, progress, crew_id, crew_name,
           scheduled_start, scheduled_end, started_at, completed_at, estimated_cost, actual_cost, materials, created_at, updated_at)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$18)
         returning id`,
        [
          code,
          reportId,
          `${r.damageType.replace("_", " ")} repair · ${r.roadName}`,
          r.workOrder.scope,
          `Repair the reported ${r.damageType.replace("_", " ")} at ${r.roadName}${r.landmark ? ` near ${r.landmark}` : ""}. Restore the surface to specification and make the section safe for all road users.`,
          r.workOrder.status,
          r.severity,
          r.workOrder.progress,
          crewUserId,
          crewName,
          scheduledStart,
          scheduledEnd,
          r.workOrder.status === "scheduled" ? null : ago(Math.max(1, (r.workOrder.start ?? 5) - 1)),
          r.workOrder.status === "completed" ? resolvedAt : null,
          r.workOrder.est,
          r.workOrder.act,
          "Cold mix asphalt, road cones, warning signage, compactor",
          ago(Math.max(1, r.daysAgo - 2)),
        ],
      );
      const woId = woRes.rows[0].id;

      const woFlow = [
        { progress: 0, message: "Work order created and crew notified.", status: "Scheduled", at: ago(Math.max(1, r.daysAgo - 2)) },
      ];
      if (r.workOrder.status !== "scheduled") {
        woFlow.push({ progress: 20, message: "Site set up, lane coned off and damaged material cut out.", status: "In progress", at: ago(Math.max(1, (r.workOrder.start ?? 5) - 1)) });
      }
      if (r.workOrder.progress > 20) {
        woFlow.push({ progress: r.workOrder.progress, message: "Base layer compacted, wearing course placed and being rolled.", status: "In progress", at: ago(1) });
      }
      if (r.workOrder.status === "completed") {
        woFlow.push({ progress: 100, message: "Repair completed, area swept and traffic reopened.", status: "Completed", at: resolvedAt });
      }
      if (r.workOrder.status === "paused") {
        woFlow.push({ progress: r.workOrder.progress, message: "Paused — waiting for replacement guardrail sections from the depot.", status: "Paused", at: ago(2) });
      }
      for (const step of woFlow) {
        await client.query(
          `insert into work_order_updates (work_order_id, author_name, message, progress, status_to, created_at)
           values ($1,$2,$3,$4,$5,$6)`,
          [woId, crewName ?? USERS[0].name, step.message, step.progress, step.status, step.at],
        );
      }
    }
  }

  console.log(`Seeded ${USERS.length} users, ${REPORTS.length} reports, ${workIndex} work orders.`);
  await client.end();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
